import os
import glob
from datasets import load_dataset
from transformers import AutoTokenizer

MODEL_PATH = "/mnt/dataset/ckpt/diffugpt-s"
INPUT_DIR = "/mnt/dataset/github-code-clean/github-code-clean"
OUTPUT_DIR = "/mnt/dataset/github-code-clean/github-code-clean-120"
SEQ_LEN = 1024
NUM_PROC = 16

def main():
    print(f"[DEBUG] INPUT_DIR = {INPUT_DIR}")

    if not os.path.exists(INPUT_DIR):
        raise FileNotFoundError(f"INPUT_DIR does not exist: {INPUT_DIR}")

    parquet_files = sorted(
        glob.glob(os.path.join(INPUT_DIR, "**", "*.parquet"), recursive=True)
    )

    if not parquet_files:
        raise FileNotFoundError(f"No parquet files found in {INPUT_DIR}")

    print(f"[DEBUG] Found {len(parquet_files)} parquet files")
    print(f"[DEBUG] First 5 files: {parquet_files[:5]}")

    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, use_fast=True)

    if tokenizer.pad_token is None:
        if tokenizer.eos_token is not None:
            tokenizer.pad_token = tokenizer.eos_token
        else:
            tokenizer.add_special_tokens({"pad_token": "[PAD]"})

    ds = load_dataset(
        "parquet",
        data_files={"train": parquet_files},
        split="train",
    )

    print(f"[DEBUG] Dataset columns: {ds.column_names}")

    # 自动识别文本列
    if "text" in ds.column_names:
        text_column = "text"
    elif "code" in ds.column_names:
        text_column = "code"
        print("[DEBUG] Using 'code' column as text input")
    else:
        raise ValueError(
            f"Need 'text' or 'code' column, got: {ds.column_names}"
        )

    # 过滤空值和空字符串
    ds = ds.filter(
        lambda x: x[text_column] is not None and str(x[text_column]).strip() != "",
        num_proc=NUM_PROC,
        desc="Filtering empty samples",
    )

    def tokenize_function(batch):
        texts = [str(x) for x in batch[text_column]]
        out = tokenizer(
            texts,
            truncation=True,
            max_length=SEQ_LEN,
            padding="max_length",
        )
        return {
            "input_ids": out["input_ids"],
            "attention_mask": out["attention_mask"],
        }

    ds = ds.map(
        tokenize_function,
        batched=True,
        num_proc=NUM_PROC,
        remove_columns=ds.column_names,
        desc="Tokenizing",
    )

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    ds.save_to_disk(OUTPUT_DIR)
    print(f"Saved to: {OUTPUT_DIR}")

if __name__ == "__main__":
    main()