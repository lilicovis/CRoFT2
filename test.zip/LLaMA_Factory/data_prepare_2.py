import os
import glob
from datasets import load_dataset
from transformers import AutoTokenizer

# 而是看 tokenizer 有没有变。没变：可以继续用 GPT2 tokenizer
MODEL_PATH = "/mnt/dataset/ckpt/diffugpt-s"
INPUT_DIR = "/mnt/dataset/open-web-math/open-web-math"
OUTPUT_DIR = "/mnt/dataset/open-web-math/open-web-math_tokenized_27"
SEQ_LEN = 1024
NUM_PROC = 16

def main():
    parquet_files = sorted(glob.glob(os.path.join(INPUT_DIR, "*.parquet")))
    if not parquet_files:
        raise FileNotFoundError(f"No parquet files found in {INPUT_DIR}")

    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, use_fast=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    ds = load_dataset(
        "parquet",
        data_files={"train": parquet_files},
        split="train",
    )

    if "text" not in ds.column_names:
        raise ValueError(f"Need 'text' column, got: {ds.column_names}")

    def tokenize_function(batch):
        out = tokenizer(
            batch["text"],
            truncation=True,
            max_length=SEQ_LEN,
            padding="max_length",
        )
        return {
            "input_ids": out["input_ids"],
            "attention_mask": out["attention_mask"],
        }

    remove_columns = [c for c in ds.column_names if c in ["text", "timestamp", "url", "id", "metadata"]]

    ds = ds.map(
        tokenize_function,
        batched=True,
        num_proc=NUM_PROC,
        remove_columns=remove_columns,
        desc="Tokenizing",
    )

    ds.save_to_disk(OUTPUT_DIR)
    print(f"Saved to: {OUTPUT_DIR}")

if __name__ == "__main__":
    main()


# from datatrove.pipeline.readers import ParquetReader
#
# # # limit determines how many documents will be streamed (remove for all)
# # # to fetch a specific dump: hf://datasets/HuggingFaceFW/fineweb/data/CC-MAIN-2024-10
# # # replace "data" with "sample/100BT" to use the 100BT sample
# # data_reader = ParquetReader("hf://datasets/HuggingFaceFW/fineweb/data", limit=1000)
# # for document in data_reader():
# #     # do something with document
# #     print(document)
#
# ###############################
# # OR for a processing pipeline:
# ###############################
#
# from datatrove.executor import LocalPipelineExecutor
# from datatrove.pipeline.readers import ParquetReader
# from datatrove.pipeline.filters import LambdaFilter
# from datatrove.pipeline.writers import JsonlWriter
#
# if __name__ == '__main__':
#     # pipeline_exec = LocalPipelineExecutor(
#     #     pipeline=[
#     #         # replace "data/CC-MAIN-2024-10" with "sample/100BT" to use the 100BT sample
#     #         # ParquetReader("hf://datasets/HuggingFaceFW/fineweb/sample/100BT"),
#     #         ParquetReader("/mnt/dataset/fineweb_s_4_gpt2"),
#     #         # LambdaFilter(lambda doc: "hugging" in doc.text),
#     #         # JsonlWriter("data/fineweb-sample")
#     #         JsonlWriter("/mnt/dataset/tmp_fineweb_s_4/fineweb-sample")
#     #     ],
#     #     tasks=4
#     # )
#     # pipeline_exec.run()
#
#     ## process
#     import json, os
#
#     # folder = './fineweb-sample/'  # replace with your folder path
#     folder = '/mnt/dataset/tmp_fineweb_s_4/fineweb-sample'
#
#     import gzip
#
#     output_file = "/mnt/6-od-fsdp-s/LLaMA-Factory/data/fineweb_s_4.jsonl"
#     open(output_file, "w").close()
#
#     # Iterate over all files in the folder
#     for filename in os.listdir(folder):
#         if filename.endswith(".jsonl.gz"):
#             with gzip.open(os.path.join(folder, filename), "rt", encoding="utf-8") as fin:
#                 with open(output_file, "a", encoding="utf-8") as fout:
#                     for line in fin:
#                         data = json.loads(line)
#                         data.pop("id", None)
#                         data.pop("metadata", None)
#                         fout.write(json.dumps(data, ensure_ascii=False) + "\n")