from datatrove.executor import LocalPipelineExecutor
from datatrove.pipeline.readers import ParquetReader
from datatrove.pipeline.writers import JsonlWriter


if __name__ == "__main__":
    pipeline_exec = LocalPipelineExecutor(
        pipeline=[
            ParquetReader("/mnt/dataset/fineweb-20/fineweb_s_16_gpt2"),
            JsonlWriter("/mnt/dataset/fineweb-20/fineweb_s_16_jsonl_shards"),
        ],
        tasks=8,
    )
    pipeline_exec.run()