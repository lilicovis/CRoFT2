from datasets import load_from_disk

DATASET_PATH = "/mnt/dataset/fineweb-26/fineweb_s_26_gpt2_tokenized"

ds = load_from_disk(DATASET_PATH)

def count_tokens(batch):
    return {"n_tokens": [sum(x) for x in batch["attention_mask"]]}

ds2 = ds.map(count_tokens, batched=True, batch_size=1000)
total_tokens = sum(ds2["n_tokens"])

print(f"Total tokens: {total_tokens:,}")
print(f"Total tokens (B): {total_tokens / 1e9:.3f}B")