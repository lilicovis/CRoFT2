import torch
from attention_patch import replace_attention_mask

replace_attention_mask()

import os
import sys


_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.abspath(os.path.join(_THIS_DIR, "..", ".."))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from LLaMA_Factory.trainer import eval_forward, generate_samples, generate_samples_v2
from model import DiscreteDiffusionModel
from argparse import ArgumentParser

from transformers import AutoConfig, AutoTokenizer

import torch.distributions as dists
import torch.nn.functional as F
from torch.utils.data import DataLoader
from f1 import compute_f1, normalize_answer
import json
from datetime import datetime
from datasets import load_from_disk, interleave_datasets
from contextlib import nullcontext
from LLaMA_Factory.diffugpt_adapter import (
    build_diffugpt_model_and_tokenizer,
    compute_diffusion_loss,
)
try:
    import wandb
except Exception:
    wandb = None


def log_benchmark_result(task_name, result_dict, log_file=None):
    if log_file is None:
        date_str = datetime.now().strftime("%Y-%m-%d")
        # log_file = f"benchmark_results_{date_str}.jsonl"
        result_file = f"/mnt/24-scale/exp/benchmark_results_{date_str}.jsonl"
        record = { "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                   "task": task_name,
                   **result_dict,
                   }
        with open(result_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")

def get_anneal_attn_mask(seq_len, bsz, dtype, device, attn_mask_ratio):
    mask = torch.full((seq_len, seq_len), 0, device=device)
    mask_cond = torch.arange(mask.size(-1), device=device)
    mask.masked_fill_(mask_cond < (mask_cond + 1).view(mask.size(-1), 1), 1)
    causal_mask = mask.to(dtype)
    
    random_mask = torch.bernoulli(torch.full((seq_len, seq_len), 0.0, device=device) + attn_mask_ratio)

    anneal_mask = torch.logical_or(causal_mask, random_mask)
    expanded_mask = anneal_mask[None, None, :, :].expand(bsz, 1, seq_len, seq_len)
    inverted_mask = 1.0 - expanded_mask.to(dtype)

    return inverted_mask.masked_fill(inverted_mask.to(torch.bool), torch.finfo(dtype).min)


def _parse_csv(s: str | None) -> list[str]:
    if s is None:
        return []
    return [x.strip() for x in s.split(",") if x.strip()]


def _parse_csv_floats(s: str | None) -> list[float]:
    if s is None:
        return []
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def _build_eval_dataset(paths: list[str], weights: list[float] | None, max_rows: int):
    shards = []
    for path in paths:
        ds = load_from_disk(path)
        n = len(ds)
        start = max(0, n - max_rows)
        ds = ds.select(range(start, n))
        shards.append(ds)
    if len(shards) == 1:
        return shards[0]
    if weights and len(weights) == len(shards):
        total = sum(weights)
        probs = [w / max(total, 1e-12) for w in weights]
    else:
        probs = [1.0 / len(shards)] * len(shards)
    return interleave_datasets(shards, probabilities=probs, seed=0, stopping_strategy="first_exhausted")


def _eval_collate_fn(samples):
    input_ids = []
    attention_masks = []
    has_any_attention = False
    for s in samples:
        ids = s["input_ids"]
        attn = s.get("attention_mask", None)
        ids_t = ids if torch.is_tensor(ids) else torch.tensor(ids, dtype=torch.long)
        input_ids.append(ids_t)
        if attn is None:
            attention_masks.append(torch.ones_like(ids_t, dtype=torch.long))
        else:
            has_any_attention = True
            attn_t = attn if torch.is_tensor(attn) else torch.tensor(attn, dtype=torch.long)
            attention_masks.append(attn_t)
    batch = {"input_ids": torch.stack(input_ids, dim=0)}
    if has_any_attention:
        batch["attention_mask"] = torch.stack(attention_masks, dim=0)
    return batch


@torch.no_grad()
def _evaluate_loss_ppl(
    model,
    tokenizer,
    dataset,
    batch_size: int,
    val_max_batches: int,
    shift: bool,
    sampling_eps: float,
    anneal_steps: int,
    dynfuse_state=None,
):
    loader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=0,
        drop_last=True,
        collate_fn=_eval_collate_fn,
    )

    model.eval()
    loss_sum = 0.0
    ce_num = 0.0
    ce_den = 0
    n_batches = 0

    use_autocast = torch.cuda.is_available()
    autocast_dtype = torch.bfloat16
    autocast_ctx = (
        torch.autocast(device_type="cuda", dtype=autocast_dtype)
        if use_autocast
        else nullcontext()
    )

    for batch in loader:
        if n_batches >= val_max_batches:
            break
        with autocast_ctx:
            loss, stats = compute_diffusion_loss(
                model=model,
                batch=batch,
                tokenizer=tokenizer,
                global_step=999999,
                anneal_steps=max(anneal_steps, 1),
                shift=shift,
                sampling_eps=sampling_eps,
                return_stats=True,
                dynfuse_state=dynfuse_state,
            )
        loss_sum += loss.item()
        mt = stats["masked_tokens"]
        ce_num += stats["masked_ce_without_1_over_t"].item() * mt
        ce_den += mt
        n_batches += 1

    if n_batches == 0:
        return {}

    val_loss = loss_sum / n_batches
    val_ce = ce_num / ce_den if ce_den > 0 else float("nan")
    return {
        "val_loss": val_loss,
        "val_ppl": math.exp(min(val_loss, 20.0)),
        "val_masked_ce": val_ce,
        "val_masked_ce_ppl": math.exp(min(val_ce, 20.0)),
        "num_batches": n_batches,
    }


def _load_model_with_state(base_model_path: str, state_dict_path: str):
    model, tokenizer = build_diffugpt_model_and_tokenizer(base_model_path)
    if state_dict_path.endswith(".pt"):
        sd = torch.load(state_dict_path, map_location="cpu")
        model.load_state_dict(sd, strict=False)
    else:
        # 允许直接传 HF 导出目录
        model, tokenizer = build_diffugpt_model_and_tokenizer(state_dict_path)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = model.to(device).eval()
    return model, tokenizer


def compare_two_checkpoints(args):
    ours_model, ours_tok = _load_model_with_state(args.base_model_path, args.ours_state_dict)
    ours_dynfuse = None
    if getattr(args, "ours_dynfuse_bundle", None):
        from open_diloco.diloco_fusion import (
            attach_offline_dynfuse_to_model,
            load_dynfuse_offline_bundle,
        )
        _dev = next(ours_model.parameters()).device
        ours_dynfuse = load_dynfuse_offline_bundle(
            args.ours_dynfuse_bundle, map_location=_dev
        )
        attach_offline_dynfuse_to_model(ours_model, ours_dynfuse)
        print(
            f"[DynFuse offline] 已加载离线路由: {args.ours_dynfuse_bundle} "
            f"(hooks 已注册，每 batch 将注入连续时间步 t)"
        )

    full_model, full_tok = _load_model_with_state(args.base_model_path, args.full_state_dict)

    max_rows = args.val_max_batches * args.batch_size * 4
    result = {
        "ours_state_dict": args.ours_state_dict,
        "full_state_dict": args.full_state_dict,
        "base_model_path": args.base_model_path,
    }

    mixed_paths = _parse_csv(args.mixed_val_paths)
    mixed_weights = _parse_csv_floats(args.mixed_val_weights)
    if mixed_paths:
        mixed_ds = _build_eval_dataset(mixed_paths, mixed_weights, max_rows=max_rows)
        ours_mixed = _evaluate_loss_ppl(
            ours_model, ours_tok, mixed_ds,
            batch_size=args.batch_size,
            val_max_batches=args.val_max_batches,
            shift=args.shift,
            sampling_eps=args.sampling_eps,
            anneal_steps=args.anneal_steps,
            dynfuse_state=ours_dynfuse,
        )
        full_mixed = _evaluate_loss_ppl(
            full_model, full_tok, mixed_ds,
            batch_size=args.batch_size,
            val_max_batches=args.val_max_batches,
            shift=args.shift,
            sampling_eps=args.sampling_eps,
            anneal_steps=args.anneal_steps,
        )
        result["mixed"] = {"ours": ours_mixed, "full": full_mixed}

    domain_names = _parse_csv(args.domain_names)
    domain_paths = _parse_csv(args.domain_paths)
    if domain_names and domain_paths and len(domain_names) == len(domain_paths):
        result["domains"] = {}
        for name, path in zip(domain_names, domain_paths):
            ds = _build_eval_dataset([path], None, max_rows=max_rows)
            ours_metrics = _evaluate_loss_ppl(
                ours_model, ours_tok, ds,
                batch_size=args.batch_size,
                val_max_batches=args.val_max_batches,
                shift=args.shift,
                sampling_eps=args.sampling_eps,
                anneal_steps=args.anneal_steps,
                dynfuse_state=ours_dynfuse,
            )
            full_metrics = _evaluate_loss_ppl(
                full_model, full_tok, ds,
                batch_size=args.batch_size,
                val_max_batches=args.val_max_batches,
                shift=args.shift,
                sampling_eps=args.sampling_eps,
                anneal_steps=args.anneal_steps,
            )
            result["domains"][name] = {"ours": ours_metrics, "full": full_metrics}

    # ── 主判断指标：val_masked_ce（纯语言建模CE，不受扩散采样项干扰）──
    # val_loss 也保留，但仅作辅助；论文主指标用 val_masked_ce
    PRIMARY = "val_masked_ce"

    # ── Macro 平均 + 胜负统计 ──────────────────────────────────────────
    macro_summary: dict = {}
    domain_names_list = list(result.get("domains", {}).keys())
    if domain_names_list:
        ours_ce_vals, full_ce_vals = [], []
        win_count = tie_count = loss_count = 0
        TIE_EPS = 0.001  # |delta| < 0.001 视为 tie

        for dname, dres in result["domains"].items():
            o_ce = dres["ours"].get(PRIMARY, float("nan"))
            f_ce = dres["full"].get(PRIMARY, float("nan"))
            ours_ce_vals.append(o_ce)
            full_ce_vals.append(f_ce)
            delta = o_ce - f_ce
            if abs(delta) < TIE_EPS:
                tie_count += 1
            elif delta < 0:
                win_count += 1   # ours 更低 = 更好
            else:
                loss_count += 1

        macro_ours = sum(ours_ce_vals) / len(ours_ce_vals)
        macro_full = sum(full_ce_vals) / len(full_ce_vals)
        macro_delta = macro_ours - macro_full

        macro_summary = {
            "macro_avg_ours_ce":   macro_ours,
            "macro_avg_full_ce":   macro_full,
            "macro_delta_ce":      macro_delta,       # <0 = ours 整体更好
            "domain_win_count":    win_count,
            "domain_tie_count":    tie_count,
            "domain_loss_count":   loss_count,
            "total_domains":       len(domain_names_list),
            "verdict": "OURS_BETTER" if macro_delta < -TIE_EPS
                       else ("TIED" if abs(macro_delta) <= TIE_EPS else "FULL_BETTER"),
        }
        result["macro_summary"] = macro_summary

    # ── 终端打印 ──────────────────────────────────────────────────────
    print(json.dumps(result, ensure_ascii=False, indent=2))

    if macro_summary:
        verdict_str = {
            "OURS_BETTER": "✅ OURS 整体更好",
            "FULL_BETTER": "❌ FULL MERGE 更好",
            "TIED":        "⚖️  基本持平",
        }.get(macro_summary["verdict"], macro_summary["verdict"])

        print("\n" + "=" * 60)
        print(f"【主指标 val_masked_ce 总结（判断依据）】")
        print(f"  Macro avg  ours={macro_summary['macro_avg_ours_ce']:.4f}  "
              f"full={macro_summary['macro_avg_full_ce']:.4f}  "
              f"delta={macro_summary['macro_delta_ce']:+.4f}")
        print(f"  域胜负：win={macro_summary['domain_win_count']}  "
              f"tie={macro_summary['domain_tie_count']}  "
              f"loss={macro_summary['domain_loss_count']}  "
              f"/ {macro_summary['total_domains']} 域")
        print(f"  结论：{verdict_str}")
        print("=" * 60 + "\n")

    if args.output_json:
        with open(args.output_json, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)

    # ── Wandb ──────────────────────────────────────────────────────────
    if args.log_wandb:
        if wandb is None:
            raise RuntimeError("log_wandb=True 但当前环境未安装 wandb")
        run_name = args.wandb_run_name or f"ckpt-compare-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        # 同一 wandb run：两次评估（如 step 200 / 400）用相同的 --wandb-run-id + resume="allow"
        init_kw: dict = dict(
            project=args.wandb_project,
            entity=args.wandb_entity,
            name=run_name,
            mode=args.wandb_mode,
            config={
                "ours_state_dict": args.ours_state_dict,
                "ours_dynfuse_bundle": args.ours_dynfuse_bundle,
                "full_state_dict": args.full_state_dict,
                "base_model_path": args.base_model_path,
                "mixed_val_paths": args.mixed_val_paths,
                "mixed_val_weights": args.mixed_val_weights,
                "domain_names": args.domain_names,
                "val_max_batches": args.val_max_batches,
                "batch_size": args.batch_size,
            },
        )
        if args.wandb_run_id:
            init_kw["id"] = args.wandb_run_id
            init_kw["resume"] = "allow"
        wb_run = wandb.init(**init_kw)
        wb_payload: dict = {}

        # ── 1. 混合总体 ─────────────────────────────────────────────
        if "mixed" in result:
            ours_m = result["mixed"].get("ours", {})
            full_m = result["mixed"].get("full", {})
            for k in ["val_loss", "val_masked_ce", "val_masked_ce_ppl"]:
                if k in ours_m:
                    wb_payload[f"mixed/ours/{k}"] = ours_m[k]
                if k in full_m:
                    wb_payload[f"mixed/full/{k}"] = full_m[k]
                if k in ours_m and k in full_m:
                    wb_payload[f"mixed/delta/{k}"] = ours_m[k] - full_m[k]  # <0=ours好

        # ── 2. 分域标量（每域一条，ours/full/delta） ─────────────────
        if "domains" in result:
            for dname, dres in result["domains"].items():
                ours_d = dres.get("ours", {})
                full_d = dres.get("full", {})
                for k in ["val_masked_ce", "val_masked_ce_ppl", "val_loss"]:
                    if k in ours_d:
                        wb_payload[f"domain/{dname}/ours/{k}"] = ours_d[k]
                    if k in full_d:
                        wb_payload[f"domain/{dname}/full/{k}"] = full_d[k]
                    if k in ours_d and k in full_d:
                        wb_payload[f"domain/{dname}/delta/{k}"] = ours_d[k] - full_d[k]

        # ── 3. Macro 汇总 ────────────────────────────────────────────
        if macro_summary:
            wb_payload["macro/ours/val_masked_ce"]  = macro_summary["macro_avg_ours_ce"]
            wb_payload["macro/full/val_masked_ce"]  = macro_summary["macro_avg_full_ce"]
            wb_payload["macro/delta/val_masked_ce"] = macro_summary["macro_delta_ce"]
            wb_payload["macro/win_count"]   = macro_summary["domain_win_count"]
            wb_payload["macro/tie_count"]   = macro_summary["domain_tie_count"]
            wb_payload["macro/loss_count"]  = macro_summary["domain_loss_count"]

        # ── 4. 可画折线图：以 eval_step 为横轴 ──────────────────────
        step = args.eval_step if args.eval_step is not None else 0
        if wb_payload:
            wandb.log(wb_payload, step=step)

        # ── 5. Table / 柱状图（artifact 较大，网络慢时会长时间“闪烁”上传）──
        if (not args.wandb_minimal) and "domains" in result:
            cols = ["domain", "ours_ce", "full_ce", "delta_ce", "winner"]
            rows = []
            for dname, dres in result["domains"].items():
                o_ce = dres["ours"].get(PRIMARY, float("nan"))
                f_ce = dres["full"].get(PRIMARY, float("nan"))
                delta = o_ce - f_ce
                winner = "ours" if delta < -0.001 else ("full" if delta > 0.001 else "tie")
                rows.append([dname, round(o_ce, 4), round(f_ce, 4), round(delta, 4), winner])
            tbl = wandb.Table(columns=cols, data=rows)
            wandb.log({"domain_comparison_table": tbl}, step=step)

            bar_data = [[r[0], r[1], r[2]] for r in rows]
            bar_tbl = wandb.Table(columns=["domain", "ours_ce", "full_ce"], data=bar_data)
            wandb.log({
                "domain_ce_bar": wandb.plot.bar(
                    bar_tbl, "domain", "ours_ce", title="val_masked_ce ours vs full (per domain)"
                )
            }, step=step)

        wb_run.finish()

def top_p_logits(logits, p=0.9):
    sorted_logits, sorted_indices = torch.sort(logits, descending=True)
    # import pdb; pdb.set_trace();
    cumulative_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)

    # Remove tokens with cumulative probability above the threshold
    sorted_indices_to_remove = cumulative_probs > p
    # Shift the indices to the right to keep the first token above the threshold
    sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
    sorted_indices_to_remove[..., 0] = 0

    mask = torch.zeros_like(logits, dtype=torch.bool, device=logits.device)
    mask = mask.scatter_(-1, sorted_indices, sorted_indices_to_remove)
    logits = logits.masked_fill(mask, torch.finfo(logits.dtype).min)
    return logits

def eval_Lambada(model, tokenizer, args):

    print("Lambada progress:")
    total_cnt = 0
    cor = 0
    with open('/mnt/24-scale/LLaMA_Factory/evaluation/evaluation/lambada_test_plain_text.txt', 'r', encoding='utf-8') as file:
        for line in file:
            total_cnt += 1
            line = line.strip()
            # import pdb; pdb.set_trace();
            x0 = tokenizer.encode(line)
            prefix = tokenizer.encode(' '.join(line.split()[:-1]))
            # attention_mask = get_anneal_attn_mask(len(xt), 1, dtype=model.lm_head.weight.dtype, device=model.device, attn_mask_ratio=1.0)
            # masked_nums = len(xt)-len(inputs)
            # xt[-masked_nums:] = [tokenizer.mask_token_id] * masked_nums
            # xt = torch.tensor([xt]).to(model.device)
            # logits = model(xt, attention_mask=attention_mask)
            # filter_logits = top_p_logits(logits/0.8, p=0.8)
            # scores = torch.log_softmax(filter_logits, dim=-1)
            # # x0_scores, x0 = scores.max(-1)
            # x0 = dists.Categorical(logits=scores).sample()
            # pred = tokenizer.decode(x0.tolist()[0][-masked_nums-1:-1])

            masked_nums = len(x0)-len(prefix)
            src_mask = [1]*len(prefix)+[0]*masked_nums
            inputs = {"input_ids": torch.tensor([x0]), "src_mask": torch.tensor([src_mask])}
            args.diffusion_steps = masked_nums
            args.logits_temp = 1.0
            res = generate_samples(model, args, tokenizer, inputs, eval=True)
            pred = tokenizer.decode(res.tolist()[0][-masked_nums:])
            # import pdb; pdb.set_trace();
            if pred.strip() == line.split()[-1].strip():
                cor += 1
            # print(total_cnt, cor/total_cnt)
    print('Lambada acc:', cor/total_cnt)
    log_benchmark_result("lambada", {"acc": cor/total_cnt})

import re
import numpy as np

def preprocess(text):
    text = text.strip()
    # NOTE: Brackets are artifacts of the WikiHow dataset portion of HellaSwag.
    text = text.replace(" [title]", ". ")
    text = re.sub("\\[.*?\\]", "", text)
    text = text.replace("  ", " ")
    return text

def eval_hellaswag(model, tokenizer, args):
    print("eval_hellaswag progress:")
    from datasets import load_dataset
    # ds = load_dataset("Rowan/hellaswag", split='validation')
    # ds = load_dataset(
    #     "parquet",
    #     data_files="/mnt/dataset/test_dataset/hellaswag/*.parquet",
    #     split='train',
    # )
    ds = load_dataset(
        "parquet",
        data_files={"validation": "/mnt/dataset/test_dataset/hellaswag/validation-00000-of-00001.parquet"},
        split="validation",
    )
    total_cnt = 0
    cor = 0
    for doc in ds:
        total_cnt += 1
        ctx = doc["ctx_a"] + " " + doc["ctx_b"].capitalize()

        query = preprocess(doc["activity_label"] + ": " + ctx)
        choices = [preprocess(ending) for ending in doc["endings"]]
        gold = int(doc["label"])

        score_list = []
        prefix = tokenizer.encode(query)

        for choice in choices:

            x0 = prefix + tokenizer.encode(choice)
            src_mask = [1]*len(prefix)+[0]*(len(x0)-len(prefix))
            inputs = {"input_ids": torch.tensor([x0]), "src_mask": torch.tensor([src_mask])}
            score = eval_forward(model, inputs, args, tokenizer)
            # import pdb; pdb.set_trace();
            score_list.append(score.tolist())
        pred = np.argmin(np.array(score_list))

        if pred == gold:
            cor += 1
        # print(total_cnt, cor/total_cnt)
        # if total_cnt % 2000 == 0:
        #     print("hellaswag", total_cnt, cor / total_cnt)
        if total_cnt == 2000:
            break
    print('hellaswag acc:', cor/total_cnt)
    log_benchmark_result("hellaswag", {"acc": cor/total_cnt})


def eval_wino(model, tokenizer, args):
    from datasets import load_dataset
    print("wino progress:")
    # ds = load_dataset("allenai/winogrande", "winogrande_xl", split='validation', trust_remote_code=True)
    ds = load_dataset(
        "parquet",
        data_files="/mnt/dataset/test_dataset/winogrande/data/*.parquet",
        split='train',
        trust_remote_code=True
    )
    total_cnt = 0
    cor = 0

    for doc in ds:
        total_cnt += 1
        
        idx = doc["sentence"].index("_")
        
        options = [doc["option1"], doc["option2"]]

        answer_to_num = {"1": 0, "2": 1}
        gold = answer_to_num[doc["answer"]]

        score_list = []
        
        for opt in options:
            target = opt 
            suffix = doc["sentence"][idx+1:].strip()
            target_id = tokenizer.encode(target, add_special_tokens=False)
            suffix_id = tokenizer.encode(suffix, add_special_tokens=False)
            prefix = doc["sentence"][:idx]
            prefix_id = tokenizer.encode(prefix, add_special_tokens=False)

            x0 = prefix_id + target_id + suffix_id
            src_mask = [1]*len(prefix_id)+[0]*(len(x0)-len(prefix_id))
            inputs = {"input_ids": torch.tensor([x0]), "src_mask": torch.tensor([src_mask])}
            score = eval_forward(model, inputs, args, tokenizer)
            # import pdb; pdb.set_trace();
            score_list.append(score.tolist())
        pred = np.argmin(np.array(score_list))

        if pred == gold:
            cor += 1
        # print(total_cnt, cor/total_cnt)
        
    print('wino acc:', cor/total_cnt)
    log_benchmark_result("wino", {"acc": cor/total_cnt})

from datasets import load_dataset
def eval_piqa(model, tokenizer, args):
    print("pipa process:")
    # ds = load_dataset("ybisk/piqa", split='validation', trust_remote_code=True)
    # ds = load_dataset("/mnt/dataset/test_dataset/piqa", split="validation", trust_remote_code=True)
    data_path = "/mnt/dataset/test_dataset/piqa/dev.jsonl"
    label_path = "/mnt/dataset/test_dataset/piqa/dev-labels.lst"

    ds = []
    with open(data_path, "r", encoding="utf-8") as f_data, open(label_path, "r", encoding="utf-8") as f_label:
        # labels = [line.strip() for line in f_label]
        labels = [int(line.strip()) for line in f_label]
        for i, line in enumerate(f_data):
            obj = json.loads(line)
            obj["label"] = labels[i]
            ds.append(obj)

    total_cnt = 0
    cor = 0
    for doc in ds:
        total_cnt += 1
        query = f"Question: {doc['goal']}\nAnswer: "
        choices = [doc["sol1"], doc["sol2"]]
        gold = doc["label"]
        score_list = []
        prefix = tokenizer.encode(query)
        for choice in choices:
            x0 = prefix + tokenizer.encode(" " + choice)
            src_mask = [1]*len(prefix)+[0]*(len(x0)-len(prefix))
            inputs = {"input_ids": torch.tensor([x0]), "src_mask": torch.tensor([src_mask])}
            score = eval_forward(model, inputs, args, tokenizer)
            # import pdb; pdb.set_trace();
            score_list.append(score.tolist())
        pred = np.argmin(np.array(score_list))
        if pred == gold:
            cor += 1
        # print(total_cnt, cor/total_cnt)
    print('pipa acc:', cor/total_cnt)
    log_benchmark_result("piqa", {"acc": cor/total_cnt})


from datasets import load_dataset
    # ds = load_dataset("allenai/social_i_qa", split='validation', trust_remote_code=True)
    # ds = load_dataset("/mnt/dataset/test_dataset/social_i_qa/social_i_qa.py", split="validation", trust_remote_code=True)
def eval_siqa(model, tokenizer, args):
    print("siqa,process:")
    data_path = "/mnt/dataset/test_dataset/social_i_qa/dev.jsonl"
    label_path = "/mnt/dataset/test_dataset/social_i_qa/dev-labels.lst"

    ds = []
    with open(data_path, "r", encoding="utf-8") as f_data, open(label_path, "r", encoding="utf-8") as f_label:
        labels = [line.strip() for line in f_label]
        for i, line in enumerate(f_data):
            obj = json.loads(line)
            obj["label"] = labels[i]
            ds.append(obj)
    total_cnt = 0
    cor = 0
    for doc in ds:
        total_cnt += 1
        query = f"Question: {doc['context']} {doc['question']}\nAnswer: "
        choices = [doc['answerA'], doc['answerB'], doc['answerC']]
        gold = int(doc["label"]) - 1
        score_list = []
        prefix = tokenizer.encode(query, add_special_tokens=False)
        for choice in choices:
            x0 = prefix + tokenizer.encode(choice, add_special_tokens=False)
            src_mask = [1]*len(prefix)+[0]*(len(x0)-len(prefix))
            inputs = {"input_ids": torch.tensor([x0]), "src_mask": torch.tensor([src_mask])}
            score = eval_forward(model, inputs, args, tokenizer)
            # import pdb; pdb.set_trace();
            score_list.append(score.tolist())
        pred = np.argmin(np.array(score_list))
        if pred == gold:
            cor += 1
        # print(total_cnt, cor/total_cnt)
    print('siqa acc:', cor/total_cnt)
    log_benchmark_result("siqa", {"acc": cor/total_cnt})



def eval_infilling(model, tokenizer, args):
    import csv
    import json

    print("ROCinfilling progress:")
    problems = []
    with open("/mnt/24-scale/LLaMA_Factory/evaluation/cloze_test_val__spring2016.csv") as f:
        reader = csv.reader(f)
        next(reader)
        for row in reader:
            sents = row[1:-3] + [row[-3] if row[-1] == "1" else row[-2]]
            problems.append(sents)

    samples = []
    total_cnt = 0
    gens = []
    refs = []

    for stories in problems:
        total_cnt += 1

        prompt = stories[0] + " " + stories[1]
        suffix = stories[3] + " " + stories[4]
        middle = stories[2]

        prefix = tokenizer.encode(prompt, add_special_tokens=False)
        suff = tokenizer.encode(suffix, add_special_tokens=False)
        middle_ids = tokenizer.encode(middle, add_special_tokens=False)

        x0 = prefix + middle_ids + suff
        src_mask = [1] * len(prefix) + [0] * len(middle_ids) + [1] * len(suff)

        inputs = {
            "input_ids": torch.tensor([x0]),
            "src_mask": torch.tensor([src_mask]),
        }

        res = generate_samples(model, args, tokenizer, inputs, eval=True)

        pred = tokenizer.decode(
            res.tolist()[0][len(prefix) - 1 : len(x0) - len(suff) - 1]
        )

        samples.append(
            {
                "pred": pred,
                "label": middle,
                "prefix": prompt,
                "suffix": suffix,
            }
        )
        gens.append(pred)
        refs.append(middle)

        if total_cnt == 1000:
            break

    from rouge_score import rouge_scorer, scoring

    scorer = rouge_scorer.RougeScorer(["rouge1", "rouge2", "rougeL"], use_stemmer=True)
    aggregator = scoring.BootstrapAggregator()

    for pred, ref in zip(gens, refs):
        scores = scorer.score(ref, pred)
        aggregator.add_scores(scores)

    agg = aggregator.aggregate()
    results = {
        "rouge1": agg["rouge1"].mid.fmeasure * 100,
        "rouge2": agg["rouge2"].mid.fmeasure * 100,
        "rougeL": agg["rougeL"].mid.fmeasure * 100,
    }
    results["rougeAvg"] = (results["rouge1"] + results["rouge2"] + results["rougeL"]) / 3

    print(
        f"rouge1={results['rouge1']:.2f}, "
        f"rouge2={results['rouge2']:.2f}, "
        f"rougeL={results['rougeL']:.2f}, "
        f"rougeAvg={results['rougeAvg']:.2f}"
    )

    with open(
        f"ROCInfill_medium_t{args.diffusion_steps}_tmp{args.logits_temp}.jsonl",
        "w",
    ) as f:
        for json_obj in samples:
            f.write(json.dumps(json_obj) + "\n")

    # log_benchmark_result("roc_infilling", results)
    log_benchmark_result("ROCinfilling progress", {"rouge1": results["rouge1"], "rouge2": results["rouge2"], "rougeL": results["rougeL"], "rougeAvg": results["rougeAvg"]})

# data_path = "/mnt/dataset/test_data/human_eval_infilling/single-line.jsonl"
    # data_path = "/mnt/dataset/test_dataset/human_eval_infilling/data/HumanEval-SingleLineInfilling.jsonl.gz"
import gzip


def humaneval_infill(model, tokenizer, args):
    import os
    import ast
    import subprocess
    import sys
    import gzip
    import json
    print("humaneval_infill-code process")
    subtasks = "single-line"
    env = os.environ.copy()
    env["PYTHONPATH"] = "/mnt/dataset/test_dataset/human_eval_infilling:" + env.get("PYTHONPATH", "")
    eval_script = "/mnt/dataset/test_dataset/human_eval_infilling/human_eval_infilling/evaluate_functional_correctness.py"
    data_path = "/mnt/dataset/test_dataset/human_eval_infilling/data/HumanEval-SingleLineInfilling.jsonl.gz"
    problems = {}
    with gzip.open(data_path, "rt", encoding="utf-8") as f:
        for line in f:
            obj = json.loads(line)
            problems[obj["task_id"]] = obj
    samples = []
    for task_id in problems:
        # import pdb; pdb.set_trace();
        prompt = problems[task_id]["prompt"]
        suffix = problems[task_id]["suffix"]
        middle = problems[task_id]["canonical_solution"]

        prefix = tokenizer.encode(prompt, add_special_tokens=False)
        suff = tokenizer.encode(suffix, add_special_tokens=False)
        x0 = prefix + tokenizer.encode(middle, add_special_tokens=False) + suff
        src_mask = [1] * len(prefix) + [0] * (len(x0) - len(prefix) - len(suff)) + [1] * len(suff)
        if len(x0) > 1000:
            print(task_id)
            samples.append(dict(task_id=task_id, completion=""))
            continue
        inputs = {"input_ids": torch.tensor([x0]), "src_mask": torch.tensor([src_mask])}
        res = generate_samples(model, args, tokenizer, inputs, eval=True)
        pred = tokenizer.decode(res.tolist()[0][len(prefix) - 1:len(x0) - len(suff) - 1])
        samples.append(dict(task_id=task_id, completion=pred))

    out_path = f"humaneval_medium_samplingv1_{subtasks}.jsonl"
    # write_jsonl(out_path, samples)
    with open(out_path, "w", encoding="utf-8") as f:
        for s in samples:
            f.write(json.dumps(s, ensure_ascii=False) + "\n")

    result = subprocess.run(
        [
            sys.executable,
            eval_script,
            "--sample_file",
            out_path,
            "--benchmark_name",
            subtasks,
        ],
        capture_output = True,
        text = True,
        env = env,
    )
    print(result.stdout)
    if result.stderr:
        print(result.stderr)
    pass_at_1 = None
    for line in result.stdout.splitlines():
        if "pass@1" in line:
            try:
                metrics = ast.literal_eval(line.strip())
                pass_at_1 = metrics.get("pass@1", None)
            except Exception:
                pass
    if pass_at_1 is not None:
        log_benchmark_result(
            "humaneval_infill",
            {"pass@1": pass_at_1, "output_file": out_path}
        )


# import evaluate
def eval_infilling(model, tokenizer, args):
    import csv
    from rouge_score import rouge_scorer, scoring
    print("roc process:")
    problems = []
    with open(f"/mnt/24-scale/LLaMA_Factory/evaluation/evaluation/cloze_test_val__spring2016.csv") as f:
    # with open("/mnt/5-diffugpt-s/evaluation/cloze_test_val__spring2016.csv") as f:
        reader = csv.reader(f)
        next(reader)
        for row in reader:
            sents = row[1:-3] + [row[-3] if row[-1] == "1" else row[-2]]
            # sents = [s if i == 0 else " " + s for i, s in enumerate(sents)]
            problems.append(sents)

    samples = []
    total_cnt = 0
    gens = []
    refs = []

    for stories in problems:
        total_cnt += 1
        # import pdb; pdb.set_trace();
        prompt = stories[0] + " " + stories[1]
        suffix = stories[3] + " " + stories[4]
        middle = stories[2]

        prefix = tokenizer.encode(prompt, add_special_tokens=False)
        suff = tokenizer.encode(suffix, add_special_tokens=False)
        x0 = prefix + tokenizer.encode(middle, add_special_tokens=False) + suff
        src_mask = [1] * len(prefix) + [0] * (len(x0) - len(prefix) - len(suff)) + [1] * len(suff)
        inputs = {"input_ids": torch.tensor([x0]), "src_mask": torch.tensor([src_mask])}
        res = generate_samples(model, args, tokenizer, inputs, eval=True)
        pred = tokenizer.decode(res.tolist()[0][len(prefix) - 1:len(x0) - len(suff) - 1])

        samples.append(dict(pred=pred, label=middle, prefix=prompt, suffix=suffix))
        gens.append(pred)
        refs.append(middle)

        if total_cnt == 1000:
            break

    scorer = rouge_scorer.RougeScorer(["rouge1", "rouge2", "rougeL"], use_stemmer=True)
    aggregator = scoring.BootstrapAggregator()

    for pred, ref in zip(gens, refs):
        scores = scorer.score(ref, pred)
        aggregator.add_scores(scores)

    agg = aggregator.aggregate()
    results = {
        "rouge1": agg["rouge1"].mid.fmeasure * 100,
        "rouge2": agg["rouge2"].mid.fmeasure * 100,
        "rougeL": agg["rougeL"].mid.fmeasure * 100,
    }
    results["rougeAvg"] = (results["rouge1"] + results["rouge2"] + results["rougeL"]) / 3

    print(
        f"rouge1={results['rouge1']:.2f}, rouge2={results['rouge2']:.2f}, rougeL={results['rougeL']:.2f}, rougeAvg={results['rougeAvg']:.2f}")

    with open(f'ROCInfill_medium_t{args.diffusion_steps}_tmp{args.logits_temp}.jsonl', 'w') as f:
        for json_obj in samples:
            f.write(json.dumps(json_obj) + '\n')
    log_benchmark_result("roc_infilling", results)


def eval_squad(model, tokenizer, args):
    from datasets import load_dataset
    print("squad progress:")
    ds = load_dataset(
        "parquet",
        data_files="/mnt/dataset/test_dataset/squad/plain_text/validation-00000-of-00001.parquet",
        split="train",
    )
    gens = []
    refs = []
    total_cnt = 0
    cor = 0
    for doc in ds:
        total_cnt += 1

        query = f"{doc['context']}\nQuesion{doc['question']}?\nAnswer: "
        labels = doc["answers"]["text"]

        encoded_labels = [tokenizer.encode(l, add_special_tokens=False) for l in labels]
        long_gold = max(encoded_labels, key=len)
        input_ids = tokenizer.encode(query)
        full = long_gold
        tokens = len(full)
        x0 = input_ids + [0] * tokens
        src_mask = [1] * len(input_ids) + [0] * tokens
        args.diffusion_steps = tokens
        inputs = {
            "input_ids": torch.tensor([x0]),
            "src_mask": torch.tensor([src_mask]),
        }
        res = generate_samples(model, args, tokenizer, inputs, eval=True)
        pred = tokenizer.decode(res.tolist()[0][len(input_ids) - 1:])
        for l in labels:
            if normalize_answer(l) in normalize_answer(pred.strip()):
                cor += 1
                break
        gens.append(pred)
        refs.append(labels)
        if total_cnt == 2000:
            break
        # print(pred, labels)
    em_acc = cor / total_cnt
    f1 = compute_f1(gens, refs)
    print("squad em acc:", em_acc)
    print("squad f1:", f1)
    log_benchmark_result("squad", {"acc": em_acc, "f1": f1})


def eval_triviaqa(model, tokenizer, args):
    from datasets import load_dataset
    import torch

    print("triviaqa progress:")
    ds = load_dataset(
        "parquet",
        data_files="/mnt/dataset/test_dataset/trivia_qa/*.parquet",
        split="train",
    )

    gens = []
    refs = []
    total_cnt = 0
    cor = 0
    skipped = 0
    max_len = 1024

    for doc in ds:
        context = ""
        if "context" in doc and doc["context"]:
            context = doc["context"]
        elif "search_results" in doc and doc["search_results"]:
            sr = doc["search_results"]
            if isinstance(sr, dict):
                descs = sr.get("search_context", []) or sr.get("description", []) or []
                if isinstance(descs, list):
                    context = "\n".join([x for x in descs if isinstance(x, str) and x.strip()])
            elif isinstance(sr, list):
                context = "\n".join([str(x) for x in sr if str(x).strip()])
        elif "entity_pages" in doc and doc["entity_pages"]:
            ep = doc["entity_pages"]
            if isinstance(ep, dict):
                wiki_context = ep.get("wiki_context", []) or ep.get("description", []) or []
                if isinstance(wiki_context, list):
                    context = "\n".join([x for x in wiki_context if isinstance(x, str) and x.strip()])

        labels = doc["answer"]["aliases"]
        normal_labels = [normalize_answer(x) for x in doc["answer"]["normalized_aliases"]]

        encoded_labels = [tokenizer.encode(l, add_special_tokens=False) for l in labels]
        long_gold = max(encoded_labels, key=len)
        tokens = len(long_gold)

        question_part = f"\nQuestion: {doc['question']}\nAnswer: "
        question_ids = tokenizer.encode(question_part, add_special_tokens=False)

        if context and len(context) > 4000:
            context = context[-4000:]

        context_ids = tokenizer.encode(context, add_special_tokens=False) if context else []

        keep_ctx_len = max_len - len(question_ids) - tokens
        if keep_ctx_len < 0:
            keep_ctx_len = 0

        context_ids = context_ids[-keep_ctx_len:]
        input_ids = context_ids + question_ids

        if len(input_ids) + tokens > max_len:
            skipped += 1
            continue

        x0 = input_ids + [0] * tokens
        src_mask = [1] * len(input_ids) + [0] * tokens
        inputs = {
            "input_ids": torch.tensor([x0]),
            "src_mask": torch.tensor([src_mask]),
        }

        old_steps = args.diffusion_steps
        try:
            args.diffusion_steps = tokens
            res = generate_samples(model, args, tokenizer, inputs, eval=True)
        finally:
            args.diffusion_steps = old_steps

        pred = tokenizer.decode(res.tolist()[0][len(input_ids) - 1:]).strip()
        norm_pred = normalize_answer(pred)

        total_cnt += 1
        if norm_pred in normal_labels:
            cor += 1
        else:
            for l in normal_labels:
                if l in norm_pred:
                    cor += 1
                    break

        gens.append(pred)
        refs.append(labels)

        if total_cnt >= 2000:
            break

    em_acc = cor / total_cnt if total_cnt else 0.0
    f1 = compute_f1(gens, refs) if gens else 0.0

    print("TriviaQA em acc:", em_acc)
    print("TriviaQA f1:", f1)
    print("TriviaQA skipped:", skipped)

    log_benchmark_result("triviaqa", {"acc": em_acc, "f1": f1, "skipped": skipped})



import math
from transformers import AutoModelForCausalLM, AutoTokenizer

def distinct_2(texts):
    total = 0
    uniq = set()
    for text in texts:
        toks = text.strip().split()
        for i in range(len(toks) - 1):
            bg = (toks[i], toks[i + 1])
            uniq.add(bg)
            total += 1
    return len(uniq) / total if total > 0 else 0.0


@torch.no_grad()
def eval_unconditional_generation(model, tokenizer, args, gpt2_large_path, num_samples=64, gen_len=1024):
    # 1) 无条件生成
    print("eval_unconditional_generation progress:")
    gens = []
    for i in range(num_samples):
        gen_len = 1023
        # gen_len = 512
        x0 = [tokenizer.eos_token_id if tokenizer.eos_token_id is not None else 0] + [0] * gen_len
        src_mask = [1] + [0] * gen_len

        # x0 = [tokenizer.eos_token_id if tokenizer.eos_token_id is not None else 0] + [0] * gen_len
        # src_mask = [1] + [0] * gen_len
        args.diffusion_steps = gen_len

        inputs = {
            "input_ids": torch.tensor([x0]),
            "src_mask": torch.tensor([src_mask]),
        }

        res = generate_samples(model, args, tokenizer, inputs, eval=True)
        pred = tokenizer.decode(res.tolist()[0][1:], skip_special_tokens=True)
        gens.append(pred)
        # print(f"[uncond] {i+1}/{num_samples}")

    # 2) 用 GPT2-large 算 generative perplexity
    eval_tok = AutoTokenizer.from_pretrained(gpt2_large_path, local_files_only=True)
    eval_lm = AutoModelForCausalLM.from_pretrained(
        gpt2_large_path,
        device_map="auto",
        torch_dtype=torch.bfloat16,
        local_files_only=True,
    )
    eval_lm.eval()

    nll_sum = 0.0
    tok_sum = 0

    for text in gens:
        ids = eval_tok(text, return_tensors="pt", truncation=True, max_length=1024).input_ids.to(eval_lm.device)
        if ids.shape[1] < 2:
            continue
        out = eval_lm(ids, labels=ids)
        n_tokens = ids.shape[1] - 1
        nll_sum += out.loss.item() * n_tokens
        tok_sum += n_tokens

    gen_ppl = math.exp(nll_sum / tok_sum) if tok_sum > 0 else float("inf")
    dist2 = distinct_2(gens)

    print(f"unconditional_generative_ppl: {gen_ppl:.4f}")
    print(f"unconditional_distinct2: {dist2:.4f}")
    log_benchmark_result("eval_unconditional_generation progress", {"ppl": gen_ppl, "distinct2": dist2})


def main():
    parser = ArgumentParser()
    parser.add_argument("--model_name", type=str, default="/mnt/12-scale/exp/ckpt/model_step_8200")
    parser.add_argument("--base_model_name", type=str, default='gpt2')
    parser.add_argument("--shift", type=bool, default=True) # do not change this
    parser.add_argument("--diffusion_steps", type=int, default=32)
    parser.add_argument("--logits_temp", type=float, default=0.95)
    parser.add_argument("--topp_temp", type=float, default=0.9)
    parser.add_argument("--verbose", type=bool, default=False) # print middle state
    parser.add_argument("--gpt2_large_path", type=str, default="/mnt/dataset/ckpt/gpt2-large")
    parser.add_argument("--compare_checkpoints", action="store_true")
    parser.add_argument("--base_model_path", type=str, default="/mnt/dataset/ckpt/diffugpt-s")
    parser.add_argument("--ours_state_dict", type=str, default=None)
    parser.add_argument(
        "--ours-dynfuse-bundle",
        dest="ours_dynfuse_bundle",
        type=str,
        default=None,
        help="与 ours 同训导出的 dynfuse_offline.pt（如 model_step_final_hf/dynfuse_offline.pt），"
        "加载后启用时间步条件 α/β 路由 + 双路 LoRA 的离线路由前向，可与 plain merge 公平对比。",
    )
    parser.add_argument("--full_state_dict", type=str, default=None)
    parser.add_argument("--mixed_val_paths", type=str, default=None)
    parser.add_argument("--mixed_val_weights", type=str, default=None)
    parser.add_argument("--domain_names", type=str, default=None)
    parser.add_argument("--domain_paths", type=str, default=None)
    parser.add_argument("--val_max_batches", type=int, default=50)
    parser.add_argument("--batch_size", type=int, default=4)
    parser.add_argument("--sampling_eps", type=float, default=1e-3)
    parser.add_argument("--anneal_steps", type=int, default=1)
    parser.add_argument("--output_json", type=str, default=None)
    parser.add_argument("--eval_step", type=int, default=None,
                        help="用作 wandb 折线图横轴（建议填 checkpoint 的 step 数，如 200）")
    parser.add_argument("--log_wandb", action="store_true")
    parser.add_argument("--wandb_project", type=str, default="hivemind_debug")
    parser.add_argument("--wandb_entity", type=str, default=None)
    parser.add_argument("--wandb_run_name", type=str, default=None)
    parser.add_argument(
        "--wandb-run-id",
        dest="wandb_run_id",
        type=str,
        default=None,
        help="固定 run id；多次 compare 时传相同 id + resume，可把 step=200/400 画在同一 run 的折线图上",
    )
    parser.add_argument("--wandb_mode", type=str, default="online", choices=["online", "offline", "disabled"])
    parser.add_argument(
        "--wandb-minimal",
        dest="wandb_minimal",
        action="store_true",
        help="仅上传标量指标（折线图够用），跳过 Table/柱状图 artifact，上传更快、终端刷屏更少",
    )

    args = parser.parse_args()

    if args.compare_checkpoints:
        if args.ours_state_dict is None or args.full_state_dict is None:
            raise ValueError("compare_checkpoints 模式下必须提供 --ours_state_dict 与 --full_state_dict")
        compare_two_checkpoints(args)
        return

    # model_name = 'gpt2'  # 'gpt2-medium', 'gpt2-large'
    model_name = args.model_name
    config = AutoConfig.from_pretrained(model_name)
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    
    # model = DiscreteDiffusionModel(args.base_model_name, config, tokenizer)
    model = DiscreteDiffusionModel.from_pretrained(
        model_name, 
        model=args.base_model_name, 
        config=config, 
        tokenizer=tokenizer,
        device='cuda'
    ).to('cuda')

    eval_Lambada(model, tokenizer, args)
    eval_hellaswag(model, tokenizer, args)
    humaneval_infill(model, tokenizer, args)
    eval_infilling(model, tokenizer, args)
    eval_wino(model, tokenizer, args)
    eval_siqa(model, tokenizer, args)
    eval_piqa(model, tokenizer, args)
    eval_squad(model, tokenizer, args)

    eval_triviaqa(model, tokenizer, args)
    eval_unconditional_generation(model, tokenizer, args, args.gpt2_large_path)


import pdb
if __name__ == "__main__":
    main()