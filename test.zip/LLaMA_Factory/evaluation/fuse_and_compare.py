#!/usr/bin/env python3
"""fuse_and_compare.py

后训练融合比较：naive_avg（直接平均）vs diloco_fusion（动态路由）

工作流程：
  1. 加载 N 个节点的 .pt 权重（从 selective merge 训练产生的带域专化节点权重）
  2. naive_avg  = 对 N 个 state_dict 做均值 → 等价于 full merge baseline
  3. diloco_fusion = 运行 apply_diloco_fusion：
       ① 关键块敏感度分析
       ② 高置信度共识提取 + 残差字典压缩
       ③ 替换关键块 MLP 为 DiLoCoFusedMLP（含可训练 router）
  4. (可选) 对 router 做轻量微调 --router-finetune-steps N
  5. 在各领域验证集评估 val_masked_ce / val_masked_ce_ppl
  6. 打印对比表并可选上传 wandb

用法示例（--node-ckpts 传每个 rank 的 **checkpoint 目录**，与 train_fsdp 保存结构一致；
若误传 global_state_dict.pt，脚本会自动改用其**父目录**加载 DCP 模型权重）：
  python fuse_and_compare.py \\
    --base-model-path /mnt/dataset/ckpt/diffugpt-s \\
    --node-ckpts "/mnt/24-scale/exp/model_step_600/diloco_rank_0,\\
                  /mnt/24-scale/exp/model_step_600/diloco_rank_1,\\
                  /mnt/24-scale/exp/model_step_600/diloco_rank_2,\\
                  /mnt/24-scale/exp/model_step_600/diloco_rank_3" \\
    --domain-names "code,edu,web,math" \\
    --domain-val-paths "/mnt/dataset/github-code-clean/github-code-clean-120,\\
                        /mnt/dataset/fineweb-edu/fineweb_edu_tokenized_15,\\
                        /mnt/dataset/fineweb-26/fineweb_s_26_gpt2_tokenized,\\
                        /mnt/dataset/open-web-math/open-web-math_tokenized_20" \\
    --router-finetune-steps 200 \\
    --router-finetune-paths "/mnt/dataset/fineweb-26/fineweb_s_26_gpt2_tokenized" \\
    --eval-step 600 \\
    --log-wandb \\
    --wandb-run-id fusion-compare-v1
"""

from __future__ import annotations

import argparse
import glob
import json
import logging
import math
import os
import pickle
import re
import shutil
import sys
import tempfile
from contextlib import contextmanager, nullcontext
from copy import deepcopy
from dataclasses import is_dataclass, replace

import torch
import torch.nn as nn
from torch.utils.data import DataLoader

# ── PYTHONPATH 注入：允许从任意目录运行本脚本 ──────────────────────────
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.abspath(os.path.join(_THIS_DIR, "..", ".."))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from attention_patch import replace_attention_mask
replace_attention_mask()

from LLaMA_Factory.diffugpt_adapter import (
    build_diffugpt_model_and_tokenizer,
    compute_diffusion_loss,
)
import torch.distributed.checkpoint as dcp
from torch.distributed.checkpoint.state_dict import get_state_dict, set_state_dict

try:
    from torch.distributed.checkpoint.api import CheckpointException
except ImportError:  # 旧版 PyTorch
    class CheckpointException(Exception):
        """占位：与 torch.distributed.checkpoint.api.CheckpointException 兼容"""

from open_diloco.ckpt_utils import FLAT_MODEL_STATE_FILE, GLOBAL_STATE_FILE
from open_diloco.diloco_fusion import apply_diloco_fusion, _static_merge
from datasets import load_from_disk, interleave_datasets

try:
    import wandb
except ImportError:
    wandb = None

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Checkpoint 加载（DCP 目录 vs 扁平 state_dict .pt）
# ─────────────────────────────────────────────────────────────────────────────

def _torch_load_checkpoint(path: str):
    """兼容 PyTorch 2.4+ 的 weights_only 默认值变更。"""
    try:
        return torch.load(path, map_location="cpu", weights_only=True)
    except Exception:
        return torch.load(path, map_location="cpu", weights_only=False)


def _resolve_node_ckpt_ref(path: str) -> tuple[str, str]:
    """
    Returns:
        ("dcp", directory)  从 torch.distributed.checkpoint 目录加载；
        ("flat", .pt 文件)  从单文件扁平 state_dict 加载。
    """
    path = os.path.abspath(path.strip())
    if os.path.isdir(path):
        return "dcp", path
    if not os.path.isfile(path):
        # 兼容 presync 目录命名：用户可能沿用旧写法传入
        #   .../presync_step_x/diloco_rank_k
        # 实际文件名是：
        #   .../presync_step_x/node_k.pt
        base = os.path.basename(path)
        m = re.match(r"diloco_rank_(\d+)$", base)
        parent = os.path.dirname(path)
        if m and os.path.isdir(parent):
            rk = int(m.group(1))
            alias_pt = os.path.join(parent, f"node_{rk}.pt")
            if os.path.isfile(alias_pt):
                log.warning(
                    "节点路径不存在: %s；检测到 presync 别名文件，自动改用: %s",
                    path,
                    alias_pt,
                )
                return "flat", alias_pt
        raise FileNotFoundError(f"节点路径不存在: {path}")
    if os.path.basename(path) == GLOBAL_STATE_FILE:
        parent = os.path.dirname(path)
        if not os.path.isdir(parent):
            raise FileNotFoundError(f"无效的 checkpoint 目录: {parent}")
        log.warning(
            "%s 只含 scheduler/loss 等元数据，不含模型权重；改为从父目录加载 DCP：%s",
            GLOBAL_STATE_FILE,
            parent,
        )
        return "dcp", parent
    return "flat", path


def _infer_distcp_shard_rank(ckpt_dir: str) -> int:
    """
    从目录内第一个分片文件名解析 RANK（与 torchrun 全局 RANK 一致）。
    """
    ckpt_dir = os.path.abspath(ckpt_dir)
    matches = sorted(glob.glob(os.path.join(ckpt_dir, "__*_*.distcp")))
    if not matches:
        raise FileNotFoundError(
            f"在 {ckpt_dir} 下未找到 __*_*.distcp 分片。"
            "请确认传入的是含 DCP 权重的 diloco_rank_k 目录。"
        )
    base = os.path.basename(matches[0])
    m = re.match(r"__(\d+)_(\d+)\.distcp$", base)
    if not m:
        log.warning("无法从 %s 解析 RANK，假定 0", base)
        return 0
    return int(m.group(1))


def _diloco_rank_from_ckpt_dir(ckpt_dir: str) -> int | None:
    base = os.path.basename(os.path.abspath(ckpt_dir))
    m = re.match(r"diloco_rank_(\d+)$", base)
    return int(m.group(1)) if m else None


def _step_root_from_diloco_ckpt(ckpt_dir: str) -> str | None:
    """.../model_step_N/diloco_rank_k -> .../model_step_N"""
    if _diloco_rank_from_ckpt_dir(ckpt_dir) is None:
        return None
    return os.path.dirname(os.path.abspath(ckpt_dir))


def _infer_world_size_from_distcp_dir(ckpt_dir: str) -> int:
    ranks: set[int] = set()
    for f in glob.glob(os.path.join(os.path.abspath(ckpt_dir), "__*_*.distcp")):
        m = re.match(r"__(\d+)_\d+\.distcp$", os.path.basename(f))
        if m:
            ranks.add(int(m.group(1)))
    return (max(ranks) + 1) if ranks else 1


def _normalize_dcp_metadata_relative_paths(merged_dir: str) -> None:
    """
    .metadata 里 relative_path 可能写成 diloco_rank_0/__1_0.distcp 或绝对路径，
    FileSystemReader 会与 merged_dir 拼接 → 指向不存在的嵌套路径。
    合并后应一律改为扁平文件名 __k_0.distcp。
    """
    meta_path = os.path.join(merged_dir, ".metadata")
    if not os.path.isfile(meta_path):
        return
    try:
        with open(meta_path, "rb") as f:
            md = pickle.load(f)
    except Exception as ex:
        log.warning("读取 .metadata 失败（跳过路径重写）: %s", ex)
        return
    sd = getattr(md, "storage_data", None)
    if not isinstance(sd, dict):
        return
    n_fix = 0
    for key, info in list(sd.items()):
        rp = getattr(info, "relative_path", None)
        if not rp or not isinstance(rp, str):
            continue
        base = os.path.basename(rp.replace("\\", "/"))
        if base == rp:
            continue
        if is_dataclass(info):
            try:
                sd[key] = replace(info, relative_path=base)
            except TypeError:
                info.relative_path = base  # type: ignore[misc]
        else:
            info.relative_path = base  # type: ignore[attr-defined]
        n_fix += 1
    if n_fix:
        log.info("已重写 .metadata 中 %d 处 relative_path 为扁平分片名", n_fix)
    try:
        with open(meta_path, "wb") as f:
            pickle.dump(md, f)
    except Exception as ex:
        log.warning("写回 .metadata 失败: %s", ex)


def _merge_step_distcp_shards(step_root: str) -> str:
    """
    多机训练时，一次 collective dcp.save 会把逻辑 checkpoint 拆成 __0_0、__1_0…
    各分片落在**不同节点**的 diloco_rank_j 目录下。单机融合前需拷到同一目录再 load。

    注意：必须用 os.listdir 拷贝 **隐藏文件** ``.metadata``；``glob.glob('*')`` 会漏掉它。
    """
    step_root = os.path.abspath(step_root)
    rank_dirs = sorted(glob.glob(os.path.join(step_root, "diloco_rank_*")))
    if len(rank_dirs) < 2:
        raise RuntimeError(
            f"{step_root} 下少于 2 个 diloco_rank_* 目录，无法合并分片。"
            "请把各节点上同一步的 diloco_rank_k 目录拷到同一文件系统后再跑融合。"
        )
    tmp = tempfile.mkdtemp(prefix="dcp_merged_")
    seen: set[str] = set()
    try:
        for rd in rank_dirs:
            for sh in glob.glob(os.path.join(rd, "__*_*.distcp")):
                bn = os.path.basename(sh)
                if bn in seen:
                    raise RuntimeError(f"合并时发现重复分片名 {bn}，请检查 {step_root}")
                seen.add(bn)
                shutil.copy2(sh, os.path.join(tmp, bn))
        # 非 .distcp：含 .metadata、global_state_dict.pt、__k_0.pt 等（listdir 含点文件）
        for rd in rank_dirs:
            try:
                names = os.listdir(rd)
            except OSError:
                continue
            for name in names:
                fpath = os.path.join(rd, name)
                if not os.path.isfile(fpath):
                    continue
                if name.endswith(".distcp"):
                    continue
                dst = os.path.join(tmp, name)
                if os.path.exists(dst):
                    continue
                shutil.copy2(fpath, dst)
        if not os.path.isfile(os.path.join(tmp, ".metadata")):
            log.warning(
                "合并目录中仍无 .metadata（各 diloco_rank_* 是否从训练机完整同步？）。"
                "若加载失败，请使用训练侧生成的 %s 或重新保存 checkpoint。",
                FLAT_MODEL_STATE_FILE,
            )
        _normalize_dcp_metadata_relative_paths(tmp)
    except Exception:
        shutil.rmtree(tmp, ignore_errors=True)
        raise
    log.info(
        "已将 %d 个 .distcp 分片合并到临时目录（来自 %s 下各 diloco_rank_*）",
        len(seen),
        step_root,
    )
    return tmp


@contextmanager
def _dcp_load_env(*, reader_rank: int, world_size: int):
    """
    单进程模拟 dcp.load 时临时设置 RANK / WORLD_SIZE。
    - 单目录仅一片：world_size=1，reader_rank=分片上的全局 RANK。
    - 合并目录含 __0..__(N-1)：world_size=N，reader_rank=当前要恢复的 diloco_rank_k 的 k。
    """
    keys = (
        "RANK",
        "LOCAL_RANK",
        "WORLD_SIZE",
        "LOCAL_WORLD_SIZE",
        "GROUP_RANK",
        "MASTER_ADDR",
        "MASTER_PORT",
    )
    saved = {k: os.environ.get(k) for k in keys}
    try:
        os.environ["RANK"] = str(reader_rank)
        os.environ["LOCAL_RANK"] = str(reader_rank)
        os.environ["WORLD_SIZE"] = str(world_size)
        os.environ["LOCAL_WORLD_SIZE"] = str(world_size)
        os.environ.pop("GROUP_RANK", None)
        os.environ.setdefault("MASTER_ADDR", "127.0.0.1")
        os.environ.setdefault("MASTER_PORT", "29500")
        log.info(
            "DCP 加载环境：RANK=%s LOCAL_RANK=%s WORLD_SIZE=%s",
            reader_rank,
            reader_rank,
            world_size,
        )
        yield
    finally:
        for k, v in saved.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


def _load_dcp_weights_into_model(
    model: nn.Module,
    ckpt_dir: str,
    base_for_reset: nn.Module,
) -> None:
    """
    从 train_fsdp 保存的目录加载模型权重（融合/评估不需要 optimizer）。

    优先级：
      1) flat_model_state_dict.pt
      2) 单目录 DCP，仅 ``model`` 键（WORLD_SIZE=1）
      3) 合并 ``model_step_*/`` 下所有 ``diloco_rank_*`` 的 .distcp 后再 load
         （多机时 __1_0 等在其它节点目录，必须拷到同一文件系统）
    """
    ckpt_dir = os.path.abspath(ckpt_dir)
    flat_path = os.path.join(ckpt_dir, FLAT_MODEL_STATE_FILE)
    if os.path.isfile(flat_path):
        log.info("  使用 %s（免 DCP 分片）", FLAT_MODEL_STATE_FILE)
        raw = _torch_load_checkpoint(flat_path)
        if not isinstance(raw, dict):
            raise ValueError(f"无效的 flat 权重: {flat_path}")
        model.load_state_dict(raw, strict=False)
        return

    merge_tmp: str | None = None
    try:
        optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4)
        model_sd, optim_sd = get_state_dict(model, optimizer)
        reader = dcp.FileSystemReader(ckpt_dir)
        try:
            shard_r = _infer_distcp_shard_rank(ckpt_dir)
            with _dcp_load_env(reader_rank=shard_r, world_size=1):
                dcp.load({"model": model_sd}, storage_reader=reader)
        except (CheckpointException, FileNotFoundError, OSError) as err:
            step_root = _step_root_from_diloco_ckpt(ckpt_dir)
            if step_root is None:
                raise RuntimeError(
                    f"DCP 加载失败且无法推断 model_step 根目录: {ckpt_dir}\n"
                    f"  • 请使用含 {FLAT_MODEL_STATE_FILE} 的 checkpoint，或保证路径为 .../model_step_N/diloco_rank_k。"
                ) from err
            log.warning(
                "单目录 DCP 失败（典型原因：其它分片在兄弟 diloco_rank_* 目录）。"
                "正在合并 %s 下各 diloco_rank_* 的 .distcp …",
                step_root,
            )
            merge_tmp = _merge_step_distcp_shards(step_root)
            model.load_state_dict(base_for_reset.state_dict(), strict=False)
            optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4)
            model_sd, optim_sd = get_state_dict(model, optimizer)
            reader = dcp.FileSystemReader(merge_tmp)
            ws = _infer_world_size_from_distcp_dir(merge_tmp)
            target_r = _diloco_rank_from_ckpt_dir(ckpt_dir)
            reader_rank = target_r if target_r is not None else 0
            try:
                with _dcp_load_env(reader_rank=reader_rank, world_size=ws):
                    dcp.load({"model": model_sd}, storage_reader=reader)
            except (CheckpointException, FileNotFoundError, OSError) as err2:
                raise RuntimeError(
                    f"合并分片后 DCP 仍失败。请确认「同一步」所有节点的 diloco_rank_* 已拷到同一父目录 "
                    f"{step_root} 下（需含 __0_0 … __{{N-1}}_0 等）。"
                    f"或重新训练保存以生成 {FLAT_MODEL_STATE_FILE}。"
                ) from err2

        set_state_dict(
            model,
            optimizer,
            model_state_dict=model_sd,
            optim_state_dict=optim_sd,
        )
    finally:
        if merge_tmp:
            shutil.rmtree(merge_tmp, ignore_errors=True)


def _state_dict_tensors_only(model: nn.Module) -> dict[str, torch.Tensor]:
    return {k: v.detach().cpu().clone() for k, v in model.state_dict().items() if torch.is_tensor(v)}


def _load_flat_state_dict_pt(path: str) -> dict[str, torch.Tensor]:
    raw = _torch_load_checkpoint(path)
    if not isinstance(raw, dict):
        raise ValueError(f"无法解析 checkpoint（非 dict）: {path}")
    # 常见嵌套
    if "model" in raw and isinstance(raw["model"], dict):
        raw = raw["model"]
    if "state_dict" in raw and isinstance(raw["state_dict"], dict):
        raw = raw["state_dict"]
    # 误把 global_state_dict.pt 当模型权重
    if "scheduler" in raw and "loss" in raw:
        if not any(str(k).startswith("denoise_model") for k in raw):
            raise ValueError(
                f"{path} 看起来像 train_fsdp 的 global_state_dict.pt（仅 scheduler/loss），"
                f"请传 diloco_rank_k **目录** 或去掉文件名只传目录。"
            )
    out = {k: v for k, v in raw.items() if torch.is_tensor(v)}
    if not out:
        raise ValueError(f"{path} 中没有张量参数，请确认是否为模型权重文件。")
    return out


def load_all_node_state_dicts(
    ckpt_refs: list[str],
    base_model: nn.Module,
) -> list[dict[str, torch.Tensor]]:
    """
    加载多节点权重为 CPU state_dict 列表。
    使用 base_model 的深拷贝 + 占位 AdamW 做 DCP 反序列化，不修改传入的 base_model。
    """
    scratch = deepcopy(base_model)
    node_sds: list[dict[str, torch.Tensor]] = []
    for ref in ckpt_refs:
        kind, resolved = _resolve_node_ckpt_ref(ref)
        if kind == "dcp":
            log.info("DCP 加载: %s", resolved)
            _load_dcp_weights_into_model(scratch, resolved, base_for_reset=base_model)
            node_sds.append(_state_dict_tensors_only(scratch))
            log.info("  ✓ %s", resolved)
        else:
            log.info("扁平权重: %s", resolved)
            node_sds.append(_load_flat_state_dict_pt(resolved))
            log.info("  ✓ %s", resolved)
    del scratch
    return node_sds


# ─────────────────────────────────────────────────────────────────────────────
# 工具函数
# ─────────────────────────────────────────────────────────────────────────────

def _parse_csv(s: str | None) -> list[str]:
    if not s:
        return []
    return [x.strip() for x in s.split(",") if x.strip()]


def _parse_csv_floats(s: str | None) -> list[float]:
    if not s:
        return []
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def _build_dataset(paths: list[str], weights: list[float] | None = None, max_rows: int = 20000):
    shards = []
    for p in paths:
        ds = load_from_disk(p)
        n = len(ds)
        start = max(0, n - max_rows)
        ds = ds.select(range(start, n))
        shards.append(ds)
    if len(shards) == 1:
        return shards[0]
    if weights and len(weights) == len(shards):
        total = sum(weights)
        probs = [w / total for w in weights]
    else:
        probs = [1.0 / len(shards)] * len(shards)
    return interleave_datasets(shards, probabilities=probs, seed=0, stopping_strategy="first_exhausted")


def _collate(samples):
    ids = [s["input_ids"] for s in samples]
    ids = [t if torch.is_tensor(t) else torch.tensor(t, dtype=torch.long) for t in ids]
    batch: dict = {"input_ids": torch.stack(ids, dim=0)}
    if "attention_mask" in samples[0]:
        attn = [s["attention_mask"] for s in samples]
        attn = [t if torch.is_tensor(t) else torch.tensor(t, dtype=torch.long) for t in attn]
        batch["attention_mask"] = torch.stack(attn, dim=0)
    return batch


# ─────────────────────────────────────────────────────────────────────────────
# 评估
# ─────────────────────────────────────────────────────────────────────────────

def _set_eval_seed(seed: int) -> None:
    """固定所有随机源，保证 naive 和 fused 在同一数据集上看到完全相同的随机 mask / timestep。"""
    import random
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    # numpy（某些 HuggingFace 内部用到）
    try:
        import numpy as np
        np.random.seed(seed)
    except ImportError:
        pass


@torch.no_grad()
def _evaluate(
    model,
    tokenizer,
    dataset,
    batch_size: int = 4,
    max_batches: int = 50,
    sampling_eps: float = 1e-3,
    anneal_steps: int = 1,
    seed: int = 42,       # ← 固定随机种子，公平对比
) -> dict:
    """
    在给定数据集上评估 diffusion loss 和 masked CE。

    seed 参数保证每次调用（naive / fused）在相同批次、相同随机 mask/timestep 下计算，
    避免 diffusion 采样随机性引入的虚假差异。
    """
    _set_eval_seed(seed)
    loader = DataLoader(
        dataset, batch_size=batch_size, shuffle=False,
        drop_last=True, num_workers=0, collate_fn=_collate,
    )
    device = next(model.parameters()).device
    model.eval()
    use_autocast = device.type == "cuda"
    ctx = torch.autocast("cuda", dtype=torch.bfloat16) if use_autocast else nullcontext()

    loss_sum, ce_num, ce_den, n = 0.0, 0.0, 0, 0
    for batch in loader:
        if n >= max_batches:
            break
        _set_eval_seed(seed + n)   # 每 batch 独立但确定的种子
        with ctx:
            loss, stats = compute_diffusion_loss(
                model=model,
                batch=batch,
                tokenizer=tokenizer,
                global_step=999999,
                anneal_steps=max(anneal_steps, 1),
                shift=True,
                sampling_eps=sampling_eps,
                return_stats=True,
            )
        loss_sum += loss.item()
        mt = stats["masked_tokens"]
        ce_num += stats["masked_ce_without_1_over_t"].item() * mt
        ce_den += mt
        n += 1

    if n == 0:
        return {}
    val_ce = ce_num / ce_den if ce_den > 0 else float("nan")
    return {
        "val_loss": loss_sum / n,
        "val_masked_ce": val_ce,
        "val_masked_ce_ppl": math.exp(min(val_ce, 20.0)),
        "n_batches": n,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Router 微调
# ─────────────────────────────────────────────────────────────────────────────

def _finetune_router(
    model,
    tokenizer,
    dataset,
    steps: int = 200,
    lr: float = 5e-4,
    batch_size: int = 4,
    sampling_eps: float = 1e-3,
    domain_datasets: list | None = None,
    domain_names: list[str] | None = None,
) -> None:
    """
    只对 router 参数（model.parameters() 中 requires_grad=True 的部分）做轻量微调。
    其余参数（MLP、注意力层等）全部冻结。

    domain_datasets 不为 None 时，启用**分域轮流训练**：
      每个域轮流送入一个 batch，给 router 提供明确的域信号。
      这让 router 能建立「code 隐状态 → 激活 code 专家」的映射，
      比混合训练收敛更快、更准。
    """
    router_params = [p for p in model.parameters() if p.requires_grad]
    if not router_params:
        log.warning("[router] 未找到可训练参数，跳过微调")
        return
    n_trainable = sum(p.numel() for p in router_params)
    n_total = sum(p.numel() for p in model.parameters())
    log.info(f"[router] 可训练参数: {n_trainable:,} / {n_total:,}  ({100.0*n_trainable/n_total:.2f}%)")

    opt = torch.optim.AdamW(router_params, lr=lr, weight_decay=1e-4)
    device = next(model.parameters()).device
    use_autocast = device.type == "cuda"
    ctx = torch.autocast("cuda", dtype=torch.bfloat16) if use_autocast else nullcontext()
    model.train()
    step = 0

    if domain_datasets and len(domain_datasets) > 1:
        # ── 分域轮流训练 ─────────────────────────────────────────────
        log.info("[router] 使用分域轮流训练（%d 个域交替送批次）", len(domain_datasets))
        domain_loaders = [
            DataLoader(ds, batch_size=batch_size, shuffle=True,
                       drop_last=True, num_workers=0, collate_fn=_collate)
            for ds in domain_datasets
        ]
        domain_iters = [iter(dl) for dl in domain_loaders]

        while step < steps:
            for di, (d_iter, d_loader) in enumerate(zip(domain_iters, domain_loaders)):
                if step >= steps:
                    break
                try:
                    batch = next(d_iter)
                except StopIteration:
                    domain_iters[di] = iter(d_loader)
                    batch = next(domain_iters[di])

                opt.zero_grad()
                with ctx:
                    loss, _ = compute_diffusion_loss(
                        model=model,
                        batch=batch,
                        tokenizer=tokenizer,
                        global_step=999999,
                        anneal_steps=1,
                        shift=True,
                        sampling_eps=sampling_eps,
                        return_stats=True,
                    )
                loss.backward()
                nn.utils.clip_grad_norm_(router_params, 1.0)
                opt.step()
                step += 1
                if step % 50 == 0:
                    dname = (domain_names or [])[di] if domain_names else str(di)
                    log.info(f"[router] step {step}/{steps}  loss={loss.item():.4f}  domain={dname}")
    else:
        # ── 混合训练（原有行为）─────────────────────────────────────
        loader = DataLoader(
            dataset, batch_size=batch_size, shuffle=True,
            drop_last=True, num_workers=0, collate_fn=_collate,
        )
        for _ in range(10000):
            for batch in loader:
                if step >= steps:
                    break
                opt.zero_grad()
                with ctx:
                    loss, _ = compute_diffusion_loss(
                        model=model,
                        batch=batch,
                        tokenizer=tokenizer,
                        global_step=999999,
                        anneal_steps=1,
                        shift=True,
                        sampling_eps=sampling_eps,
                        return_stats=True,
                    )
                loss.backward()
                nn.utils.clip_grad_norm_(router_params, 1.0)
                opt.step()
                step += 1
                if step % 50 == 0:
                    log.info(f"[router] step {step}/{steps}  loss={loss.item():.4f}")
            if step >= steps:
                break

    model.eval()
    log.info(f"[router] 微调完成（共 {step} 步）")


# ─────────────────────────────────────────────────────────────────────────────
# 主流程
# ─────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="后训练融合比较：naive_avg vs diloco_fusion",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    # ── 必须参数 ──
    parser.add_argument("--base-model-path", required=True,
                        help="预训练 diffugpt-s checkpoint 路径")
    parser.add_argument("--node-ckpts", required=True,
                        help="N 个节点：每个为 model_step_*/diloco_rank_k **目录**（DCP），"
                             "或单文件扁平 state_dict .pt；误传 global_state_dict.pt 会自动用父目录")
    parser.add_argument("--domain-names", required=True,
                        help="领域名称，逗号分隔，如 code,edu,web,math")
    parser.add_argument("--domain-val-paths", required=True,
                        help="各领域验证集路径，逗号分隔（与 domain-names 一一对应）")
    # ── 混合验证集（可选）──
    parser.add_argument("--mixed-val-paths", default=None, help="混合验证集数据集路径（可选）")
    parser.add_argument("--mixed-val-weights", default=None, help="混合验证集权重，逗号分隔（可选）")
    # ── Router 微调（可选）──
    parser.add_argument("--router-finetune-steps", type=int, default=0,
                        help="router 微调步数（0 = 跳过，推荐 100–500 步）")
    parser.add_argument("--router-finetune-paths", default=None,
                        help="用于 router 微调的数据路径（默认复用 mixed-val-paths）")
    parser.add_argument("--router-lr", type=float, default=5e-4, help="router 学习率")
    # ── 融合参数 ──
    parser.add_argument("--sensitivity-threshold", type=float, default=0.3,
                        help="关键块敏感度阈值，基于 min-max 归一化后的 L2 距离，∈ [0,1]。"
                             "0.3 = 选取相对差异最大的前 70%% 块（即 top-(1-thresh) 百分位）。"
                             "越小 → 更多块做动态融合；建议从 0.3 开始，模型越收敛可适当增大。")
    parser.add_argument("--num-atoms", type=int, default=4, help="残差字典原子数")
    parser.add_argument("--eval-seed", type=int, default=42,
                        help="评估随机种子（固定后 naive/fused 看到完全相同的 timestep/mask）")
    # ── 评估参数 ──
    parser.add_argument("--val-max-batches", type=int, default=50)
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--sampling-eps", type=float, default=1e-3)
    parser.add_argument("--anneal-steps", type=int, default=1)
    # ── 输出 ──
    parser.add_argument("--output-json", default=None, help="结果保存路径（.json）")
    # ── Wandb ──
    parser.add_argument("--eval-step", type=int, default=None,
                        help="wandb 折线图横轴（建议填 checkpoint 的 step，如 200/400/600）")
    parser.add_argument("--log-wandb", action="store_true")
    parser.add_argument("--wandb-project", default="hivemind_debug")
    parser.add_argument("--wandb-entity", default=None)
    parser.add_argument("--wandb-run-name", default="fusion-vs-naive")
    parser.add_argument("--wandb-run-id", default=None,
                        help="固定 run id，多次对不同 step 运行时绘制同一折线图")
    parser.add_argument("--wandb-mode", default="online",
                        choices=["online", "offline", "disabled"])
    args = parser.parse_args()

    ckpt_paths = _parse_csv(args.node_ckpts)

    device = "cuda" if torch.cuda.is_available() else "cpu"

    # ── 先加载 base（供任务向量 Δ = node − base，且 DCP 需同一架构）────────
    log.info("加载 base 预训练模型...")
    base_model, tokenizer = build_diffugpt_model_and_tokenizer(args.base_model_path)

    log.info("加载 %d 个节点权重 …", len(ckpt_paths))
    node_sds = load_all_node_state_dicts(ckpt_paths, base_model)
    assert len(node_sds) >= 2, "至少需要 2 个节点权重"

    # ── 构建 naive_avg 模型 ───────────────────────────────────────────
    log.info("构建 naive_avg（静态均值融合）...")
    naive_sd = _static_merge(node_sds)
    naive_model = deepcopy(base_model)
    naive_model.load_state_dict(naive_sd, strict=False)
    naive_model = naive_model.to(device).eval()
    log.info("  ✓ naive_avg 就绪")

    # ── 构建 diloco_fusion 模型 ───────────────────────────────────────
    log.info("运行 diloco_fusion 分析与构建...")
    fused_model = apply_diloco_fusion(
        base_model=deepcopy(base_model),
        node_state_dicts=node_sds,
        sensitivity_threshold=args.sensitivity_threshold,
        num_atoms=args.num_atoms,
        init_alpha=0.0,
        init_beta=0.0,
    )
    fused_model = fused_model.to(device)
    log.info("  ✓ diloco_fusion 模型就绪（init: α=0, β=0 → 等价 naive_avg 初始性能）")

    # ── (可选) router 轻量微调 ────────────────────────────────────────
    if args.router_finetune_steps > 0:
        ft_paths = _parse_csv(
            args.router_finetune_paths
            or args.mixed_val_paths
            or args.domain_val_paths
        )
        if ft_paths:
            max_rows = args.router_finetune_steps * args.batch_size * 8
            # 优先用分域数据集做轮流训练（效果更好）
            # 若 router_finetune_paths 与 domain_val_paths 数量相等，则认为是分域路径
            domain_names_ft = _parse_csv(args.domain_names)
            domain_val_paths_ft = _parse_csv(args.domain_val_paths)
            ft_is_per_domain = (len(ft_paths) == len(domain_names_ft))
            if ft_is_per_domain:
                log.info(
                    "开始 router 分域轮流微调（%d 个域 × %d 步）…",
                    len(ft_paths), args.router_finetune_steps,
                )
                domain_datasets = [
                    _build_dataset([p], max_rows=max_rows // len(ft_paths))
                    for p in ft_paths
                ]
                mixed_ft_ds = _build_dataset(ft_paths, max_rows=max_rows)
                _finetune_router(
                    fused_model, tokenizer, mixed_ft_ds,
                    steps=args.router_finetune_steps,
                    lr=args.router_lr,
                    batch_size=args.batch_size,
                    sampling_eps=args.sampling_eps,
                    domain_datasets=domain_datasets,
                    domain_names=domain_names_ft,
                )
            else:
                log.info("开始 router 混合微调（%d 步）…", args.router_finetune_steps)
                ft_ds = _build_dataset(ft_paths, max_rows=max_rows)
                _finetune_router(
                    fused_model, tokenizer, ft_ds,
                    steps=args.router_finetune_steps,
                    lr=args.router_lr,
                    batch_size=args.batch_size,
                    sampling_eps=args.sampling_eps,
                )
        else:
            log.warning("未指定微调数据路径，跳过 router 微调")
    fused_model = fused_model.eval()

    # ── 评估 ─────────────────────────────────────────────────────────
    domain_names = _parse_csv(args.domain_names)
    domain_val_paths = _parse_csv(args.domain_val_paths)
    assert len(domain_names) == len(domain_val_paths), \
        "domain-names 和 domain-val-paths 数量不一致"

    max_rows = args.val_max_batches * args.batch_size * 4
    results: dict = {"config": {"ckpts": ckpt_paths, "step": args.eval_step}}

    # 混合验证集
    if args.mixed_val_paths:
        mixed_paths = _parse_csv(args.mixed_val_paths)
        mixed_weights = _parse_csv_floats(args.mixed_val_weights)
        mixed_ds = _build_dataset(mixed_paths, mixed_weights, max_rows=max_rows)
        log.info("─── 评估：混合验证集（seed=%d）───", args.eval_seed)
        naive_mixed = _evaluate(naive_model, tokenizer, mixed_ds, args.batch_size,
                                args.val_max_batches, args.sampling_eps, args.anneal_steps,
                                seed=args.eval_seed)
        fused_mixed = _evaluate(fused_model, tokenizer, mixed_ds, args.batch_size,
                                args.val_max_batches, args.sampling_eps, args.anneal_steps,
                                seed=args.eval_seed)
        results["mixed"] = {"naive": naive_mixed, "fused": fused_mixed}
        log.info(
            f"  混合  naive_masked_ce={naive_mixed.get('val_masked_ce', float('nan')):.4f}  "
            f"fused_masked_ce={fused_mixed.get('val_masked_ce', float('nan')):.4f}"
        )

    # 各领域验证集
    PRIMARY = "val_masked_ce"
    wins, ties, losses = 0, 0, 0
    domain_results: dict = {}

    log.info("─── 评估：各领域验证集（seed=%d）───", args.eval_seed)
    for name, path in zip(domain_names, domain_val_paths):
        ds = _build_dataset([path], max_rows=max_rows)
        naive_m = _evaluate(naive_model, tokenizer, ds, args.batch_size,
                            args.val_max_batches, args.sampling_eps, args.anneal_steps,
                            seed=args.eval_seed)
        fused_m = _evaluate(fused_model, tokenizer, ds, args.batch_size,
                            args.val_max_batches, args.sampling_eps, args.anneal_steps,
                            seed=args.eval_seed)
        domain_results[name] = {"naive": naive_m, "fused": fused_m}

        nv = naive_m.get(PRIMARY, float("inf"))
        fv = fused_m.get(PRIMARY, float("inf"))
        delta = nv - fv  # 正值 = fused 更好
        if delta > 0.01:
            tag, wins = "WIN ✓", wins + 1
        elif delta < -0.01:
            tag, losses = "LOSS ✗", losses + 1
        else:
            tag, ties = "TIE ~", ties + 1
        log.info(
            f"  [{name:>6}]  naive={nv:.4f}  fused={fv:.4f}  Δ={delta:+.4f}  {tag}"
        )

    results["domains"] = domain_results

    # 宏平均
    naive_ces = [domain_results[n]["naive"].get(PRIMARY, float("nan")) for n in domain_names]
    fused_ces = [domain_results[n]["fused"].get(PRIMARY, float("nan")) for n in domain_names]
    macro_naive = sum(naive_ces) / len(naive_ces)
    macro_fused = sum(fused_ces) / len(fused_ces)
    macro_delta = macro_naive - macro_fused

    results["macro"] = {
        "naive_masked_ce": macro_naive,
        "fused_masked_ce": macro_fused,
        "delta": macro_delta,
    }
    results["verdict"] = {"wins": wins, "ties": ties, "losses": losses}

    log.info("")
    log.info("═" * 60)
    log.info(f"  宏平均 val_masked_ce:  naive={macro_naive:.4f}  fused={macro_fused:.4f}  Δ={macro_delta:+.4f}")
    log.info(f"  领域胜/平/负:          {wins} / {ties} / {losses}")
    verdict_str = "fused 更好" if macro_delta > 0 else ("naive_avg 更好" if macro_delta < 0 else "持平")
    log.info(f"  总结论：{verdict_str}")
    log.info("═" * 60)

    # ── 保存 JSON ────────────────────────────────────────────────────
    if args.output_json:
        os.makedirs(os.path.dirname(os.path.abspath(args.output_json)), exist_ok=True)
        with open(args.output_json, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        log.info(f"结果已保存: {args.output_json}")

    # ── Wandb 上报 ───────────────────────────────────────────────────
    if args.log_wandb and wandb is not None:
        run_kwargs: dict = dict(
            project=args.wandb_project,
            entity=args.wandb_entity,
            name=args.wandb_run_name,
            mode=args.wandb_mode,
            resume="allow",
        )
        if args.wandb_run_id:
            run_kwargs["id"] = args.wandb_run_id
        run = wandb.init(**run_kwargs)
        step = args.eval_step
        log_dict: dict = {}

        if "mixed" in results:
            for k, v in results["mixed"]["naive"].items():
                if isinstance(v, (int, float)):
                    log_dict[f"mixed/naive/{k}"] = v
            for k, v in results["mixed"]["fused"].items():
                if isinstance(v, (int, float)):
                    log_dict[f"mixed/fused/{k}"] = v

        for name in domain_names:
            for k, v in domain_results[name]["naive"].items():
                if isinstance(v, (int, float)):
                    log_dict[f"domain/{name}/naive/{k}"] = v
            for k, v in domain_results[name]["fused"].items():
                if isinstance(v, (int, float)):
                    log_dict[f"domain/{name}/fused/{k}"] = v

        log_dict["macro/naive_masked_ce"] = macro_naive
        log_dict["macro/fused_masked_ce"] = macro_fused
        log_dict["macro/delta"] = macro_delta
        log_dict["verdict/wins"] = wins
        log_dict["verdict/ties"] = ties
        log_dict["verdict/losses"] = losses

        wandb.log(log_dict, step=step)
        wandb.finish()
        log.info("[wandb] 上报完成")

    # 最终也打印一遍 JSON
    print(json.dumps(results, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
