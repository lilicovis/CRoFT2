#!/usr/bin/env python3
"""create_specialized_nodes.py

从一个已有的（merged/平均）checkpoint 出发，
对 4 份拷贝各自在一个专属域上微调若干步，
产生有真实分歧的"节点"权重，供 fuse_and_compare.py 使用。

用法：
  python LLaMA_Factory/evaluation/create_specialized_nodes.py \
    --base-model-path /mnt/dataset/ckpt/diffugpt-s \
    --merged-ckpt-dir /mnt/24-scale/exp/model_step_600/diloco_rank_0 \
    --domain-names "code,edu,web,math" \
    --domain-paths \
      "/mnt/dataset/github-code-clean/github-code-clean-120,\
       /mnt/dataset/fineweb-edu/fineweb_edu_tokenized_15,\
       /mnt/dataset/fineweb-26/fineweb_s_26_gpt2_tokenized,\
       /mnt/dataset/open-web-math/open-web-math_tokenized_27" \
    --finetune-steps 200 \
    --lr 2e-5 \
    --output-dir /mnt/24-scale/exp/specialized_nodes_step600
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from copy import deepcopy

import torch
import torch.nn as nn
from torch.utils.data import DataLoader

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.abspath(os.path.join(_THIS_DIR, "..", ".."))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from attention_patch import replace_attention_mask
replace_attention_mask()

from LLaMA_Factory.diffugpt_adapter import (
    build_diffugpt_model_and_tokenizer,
    compute_diffusion_loss,
)
from LLaMA_Factory.evaluation.fuse_and_compare import (
    _parse_csv,
    _build_dataset,
    _collate,
    load_all_node_state_dicts,
    _static_merge,
)
from contextlib import nullcontext

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger(__name__)


def _set_seed(seed: int) -> None:
    import random
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    try:
        import numpy as np
        np.random.seed(seed)
    except ImportError:
        pass


def domain_finetune(
    model: nn.Module,
    tokenizer,
    dataset,
    steps: int = 200,
    lr: float = 2e-5,
    batch_size: int = 4,
    sampling_eps: float = 1e-3,
    seed: int = 0,
) -> nn.Module:
    """在单个域数据集上对模型做轻量微调，让模型专化于该域。"""
    _set_seed(seed)
    model.train()
    for p in model.parameters():
        p.requires_grad_(True)

    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    loader = DataLoader(
        dataset, batch_size=batch_size, shuffle=True,
        drop_last=True, num_workers=0, collate_fn=_collate,
    )
    device = next(model.parameters()).device
    use_autocast = device.type == "cuda"
    ctx = torch.autocast("cuda", dtype=torch.bfloat16) if use_autocast else nullcontext()

    step = 0
    for _ in range(9999):
        for batch in loader:
            if step >= steps:
                break
            opt.zero_grad()
            with ctx:
                loss, _ = compute_diffusion_loss(
                    model=model,
                    batch=batch,
                    tokenizer=tokenizer,
                    global_step=999999,
                    anneal_steps=1,
                    shift=True,
                    sampling_eps=sampling_eps,
                    return_stats=True,
                )
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            step += 1
            if step % 50 == 0:
                log.info("  step %d/%d  loss=%.4f", step, steps, loss.item())
        if step >= steps:
            break

    model.eval()
    log.info("  微调完成（共 %d 步）", step)
    return model


def main():
    parser = argparse.ArgumentParser(
        description="从已有 checkpoint 对每个域做专化微调，产生节点分歧权重",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--base-model-path", required=True)
    parser.add_argument("--merged-ckpt-dir", required=True,
                        help="已有的 merged checkpoint 目录（diloco_rank_k 或含 flat_model_state_dict.pt）。"
                             "若为 'naive'，则直接用 --node-ckpts 的均值。")
    parser.add_argument("--node-ckpts", default=None,
                        help="若 merged-ckpt-dir='naive'，需提供各节点 ckpt 以计算均值")
    parser.add_argument("--domain-names", required=True, help="领域名，逗号分隔")
    parser.add_argument("--domain-paths", required=True, help="各域训练数据路径，逗号分隔")
    parser.add_argument("--finetune-steps", type=int, default=200,
                        help="每个域微调步数（推荐 100-500，步数越多专化越强）")
    parser.add_argument("--lr", type=float, default=2e-5)
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--sampling-eps", type=float, default=1e-3)
    parser.add_argument("--output-dir", required=True, help="输出目录，每个域保存一个 node_k.pt")
    args = parser.parse_args()

    domain_names = _parse_csv(args.domain_names)
    domain_paths = _parse_csv(args.domain_paths)
    assert len(domain_names) == len(domain_paths), "domain-names 与 domain-paths 数量不一致"

    device = "cuda" if torch.cuda.is_available() else "cpu"
    os.makedirs(args.output_dir, exist_ok=True)

    log.info("加载 base 预训练模型...")
    base_model, tokenizer = build_diffugpt_model_and_tokenizer(args.base_model_path)

    # ── 加载起点 merged 模型 ────────────────────────────────────────
    log.info("加载 merged 起点权重...")
    if args.merged_ckpt_dir == "naive":
        assert args.node_ckpts, "--merged-ckpt-dir='naive' 时需提供 --node-ckpts"
        node_sds = load_all_node_state_dicts(_parse_csv(args.node_ckpts), base_model)
        merged_sd = _static_merge(node_sds)
        merged_model = deepcopy(base_model)
        merged_model.load_state_dict(merged_sd, strict=False)
    else:
        node_sds = load_all_node_state_dicts([args.merged_ckpt_dir], base_model)
        merged_sd = node_sds[0]
        merged_model = deepcopy(base_model)
        merged_model.load_state_dict(merged_sd, strict=False)
    log.info("  ✓ merged 起点就绪")

    # ── 对每个域做专化微调 ─────────────────────────────────────────
    node_out_paths: list[str] = []
    for i, (name, path) in enumerate(zip(domain_names, domain_paths)):
        log.info("═" * 55)
        log.info("[%d/%d] 域 '%s'  数据：%s", i + 1, len(domain_names), name, path)
        node_model = deepcopy(merged_model).to(device)

        max_rows = args.finetune_steps * args.batch_size * 10
        ds = _build_dataset([path], max_rows=max_rows)

        domain_finetune(
            node_model, tokenizer, ds,
            steps=args.finetune_steps,
            lr=args.lr,
            batch_size=args.batch_size,
            sampling_eps=args.sampling_eps,
            seed=i * 1000,
        )

        out_path = os.path.join(args.output_dir, f"node_{i}_{name}.pt")
        sd = {k: v.detach().cpu().clone()
              for k, v in node_model.state_dict().items()
              if torch.is_tensor(v)}
        torch.save(sd, out_path)
        log.info("  ✓ 保存至 %s", out_path)
        node_out_paths.append(out_path)
        del node_model

    # ── 打印后续 fuse_and_compare 命令 ─────────────────────────────
    node_ckpts_str = ",".join(node_out_paths)
    log.info("")
    log.info("═" * 55)
    log.info("所有节点权重已保存。接下来运行 fuse_and_compare：")
    log.info("")
    cmd = f"""python LLaMA_Factory/evaluation/fuse_and_compare.py \\
  --base-model-path {args.base_model_path} \\
  --node-ckpts "{node_ckpts_str}" \\
  --domain-names "{args.domain_names}" \\
  --domain-val-paths "<各域验证集路径，逗号分隔>" \\
  --mixed-val-paths "<混合验证集路径>" \\
  --mixed-val-weights "0.25,0.25,0.25,0.25" \\
  --sensitivity-threshold 0.3 \\
  --router-finetune-steps 300 \\
  --router-finetune-paths "<混合微调数据路径>" \\
  --val-max-batches 50 --batch-size 4 \\
  --eval-step 600 \\
  --output-json {args.output_dir}/fusion_compare.json \\
  --log-wandb --wandb-project hivemind_debug"""
    print(cmd)


if __name__ == "__main__":
    main()
