import torch
from attention_patch import replace_attention_mask

replace_attention_mask()

import os
import sys

# 允许从任意工作目录运行本脚本：
# 自动将项目根目录（.../24-scale）加入 PYTHONPATH，
# 避免出现 ModuleNotFoundError: No module named 'LLaMA_Factory'
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.abspath(os.path.join(_THIS_DIR, "../.."))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from LLaMA_Factory.trainer import eval_forward, generate_samples, generate_samples_v2
from model import DiscreteDiffusionModel
from argparse import ArgumentParser

from transformers import AutoConfig, AutoTokenizer

import torch.distributions as dists
import torch.nn.functional as F
from torch.utils.data import DataLoader
from f1 import compute_f1, normalize_answer
import json
from datetime import datetime
import time
from datasets import load_from_disk, interleave_datasets
from contextlib import nullcontext
from LLaMA_Factory.diffugpt_adapter import (
    build_diffugpt_model_and_tokenizer,
    compute_diffusion_loss,
)
try:
    import wandb
except Exception:
    wandb = None


def log_benchmark_result(task_name, result_dict, log_file=None):
    if log_file is None:
        date_str = datetime.now().strftime("%Y-%m-%d")
        # log_file = f"benchmark_results_{date_str}.jsonl"
        result_file = f"/mnt/24-scale/exp/benchmark_results_{date_str}.jsonl"
        record = { "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                   "task": task_name,
                   **result_dict,
                   }
        with open(result_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")

def get_anneal_attn_mask(seq_len, bsz, dtype, device, attn_mask_ratio):
    mask = torch.full((seq_len, seq_len), 0, device=device)
    mask_cond = torch.arange(mask.size(-1), device=device)
    mask.masked_fill_(mask_cond < (mask_cond + 1).view(mask.size(-1), 1), 1)
    causal_mask = mask.to(dtype)
    
    random_mask = torch.bernoulli(torch.full((seq_len, seq_len), 0.0, device=device) + attn_mask_ratio)

    anneal_mask = torch.logical_or(causal_mask, random_mask)
    expanded_mask = anneal_mask[None, None, :, :].expand(bsz, 1, seq_len, seq_len)
    inverted_mask = 1.0 - expanded_mask.to(dtype)

    return inverted_mask.masked_fill(inverted_mask.to(torch.bool), torch.finfo(dtype).min)


def _parse_csv(s: str | None) -> list[str]:
    if s is None:
        return []
    return [x.strip() for x in s.split(",") if x.strip()]


def _parse_csv_floats(s: str | None) -> list[float]:
    if s is None:
        return []
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def _build_eval_dataset(paths: list[str], weights: list[float] | None, max_rows: int):
    shards = []
    for path in paths:
        ds = load_from_disk(path)
        n = len(ds)
        start = max(0, n - max_rows)
        ds = ds.select(range(start, n))
        shards.append(ds)
    if len(shards) == 1:
        return shards[0]
    if weights and len(weights) == len(shards):
        total = sum(weights)
        probs = [w / max(total, 1e-12) for w in weights]
    else:
        probs = [1.0 / len(shards)] * len(shards)
    return interleave_datasets(shards, probabilities=probs, seed=0, stopping_strategy="first_exhausted")


def _eval_collate_fn(samples):
    input_ids = []
    attention_masks = []
    has_any_attention = False
    for s in samples:
        ids = s["input_ids"]
        attn = s.get("attention_mask", None)
        ids_t = ids if torch.is_tensor(ids) else torch.tensor(ids, dtype=torch.long)
        input_ids.append(ids_t)
        if attn is None:
            attention_masks.append(torch.ones_like(ids_t, dtype=torch.long))
        else:
            has_any_attention = True
            attn_t = attn if torch.is_tensor(attn) else torch.tensor(attn, dtype=torch.long)
            attention_masks.append(attn_t)
    batch = {"input_ids": torch.stack(input_ids, dim=0)}
    if has_any_attention:
        batch["attention_mask"] = torch.stack(attention_masks, dim=0)
    return batch


@torch.no_grad()
def _evaluate_loss_ppl(
    model,
    tokenizer,
    dataset,
    batch_size: int,
    val_max_batches: int,
    shift: bool,
    sampling_eps: float,
    anneal_steps: int,
    dynfuse_state=None,
):
    loader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=0,
        drop_last=True,
        collate_fn=_eval_collate_fn,
    )

    model.eval()
    loss_sum = 0.0
    ce_num = 0.0
    ce_den = 0
    n_batches = 0

    use_autocast = torch.cuda.is_available()
    autocast_dtype = torch.bfloat16
    autocast_ctx = (
        torch.autocast(device_type="cuda", dtype=autocast_dtype)
        if use_autocast
        else nullcontext()
    )

    for batch in loader:
        if n_batches >= val_max_batches:
            break
        with autocast_ctx:
            loss, stats = compute_diffusion_loss(
                model=model,
                batch=batch,
                tokenizer=tokenizer,
                global_step=999999,
                anneal_steps=max(anneal_steps, 1),
                shift=shift,
                sampling_eps=sampling_eps,
                return_stats=True,
                dynfuse_state=dynfuse_state,
            )
        loss_sum += loss.item()
        mt = stats["masked_tokens"]
        ce_num += stats["masked_ce_without_1_over_t"].item() * mt
        ce_den += mt
        n_batches += 1

    if n_batches == 0:
        return {}

    val_loss = loss_sum / n_batches
    val_ce = ce_num / ce_den if ce_den > 0 else float("nan")
    return {
        "val_loss": val_loss,
        "val_ppl": math.exp(min(val_loss, 20.0)),
        "val_masked_ce": val_ce,
        "val_masked_ce_ppl": math.exp(min(val_ce, 20.0)),
        "num_batches": n_batches,
    }


def _load_model_with_state(base_model_path: str, state_dict_path: str):
    model, tokenizer = build_diffugpt_model_and_tokenizer(base_model_path)
    if state_dict_path.endswith(".pt"):
        sd = torch.load(state_dict_path, map_location="cpu")
        model.load_state_dict(sd, strict=False)
    else:
        # 允许直接传 HF 导出目录
        model, tokenizer = build_diffugpt_model_and_tokenizer(state_dict_path)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = model.to(device).eval()
    return model, tokenizer


def _load_model_with_dynfuse(
    base_model_path: str,
    state_dict_path: str | None,
    node_state_dicts: list[str] | None = None,
    dynfuse_bundle_path: str | None = None,
):
    """加载模型，支持以下三种模式：
    1. 单 checkpoint（state_dict_path）。
    2. 多节点 checkpoint 简单平均（node_state_dicts）作为 full-merge baseline。
    3. 在上述基础上附加 DynFuse 离线 router（dynfuse_bundle_path）。
    返回 (model, tokenizer, dynfuse_state_or_None)。
    """
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model, tokenizer = build_diffugpt_model_and_tokenizer(base_model_path)

    def _resolve_ckpt_file(path_or_dir: str) -> str:
        """支持传 checkpoint 文件或目录；目录时自动挑选常见权重文件。"""
        if os.path.isfile(path_or_dir):
            return path_or_dir
        if not os.path.isdir(path_or_dir):
            raise FileNotFoundError(f"checkpoint 路径不存在: {path_or_dir}")
        candidates = [
            "flat_model_state_dict.pt",  # 当前 train_fsdp.py 保存产物（优先）
            "model.pt",
            "global_state_dict.pt",
            "pytorch_model.bin",
            "model.safetensors",
        ]
        for fn in candidates:
            p = os.path.join(path_or_dir, fn)
            if os.path.isfile(p):
                return p
        raise FileNotFoundError(
            f"目录 {path_or_dir} 下未找到可加载权重文件，已尝试: {candidates}"
        )

    if node_state_dicts and len(node_state_dicts) > 0:
        # 多节点权重平均（full-merge 方式构建共享底座）
        print(f"[offline] 从 {len(node_state_dicts)} 个节点 checkpoint 平均权重...")
        avg_sd: dict | None = None
        for path in node_state_dicts:
            ckpt_path = _resolve_ckpt_file(path)
            if ckpt_path.endswith(".safetensors"):
                from safetensors.torch import load_file as _load_safetensors
                sd = _load_safetensors(ckpt_path, device="cpu")
            else:
                sd = torch.load(ckpt_path, map_location="cpu")
            # 兼容包有 "model" key 的 checkpoint
            if isinstance(sd, dict) and "model" in sd and not any(
                k.startswith("transformer") for k in sd
            ):
                sd = sd["model"]
            if avg_sd is None:
                avg_sd = {k: v.float().clone() for k, v in sd.items()}
            else:
                for k in avg_sd:
                    if k in sd:
                        avg_sd[k] += sd[k].float()
        n = len(node_state_dicts)
        avg_sd = {k: (v / n).to(next(iter(model.parameters())).dtype) for k, v in avg_sd.items()}
        model.load_state_dict(avg_sd, strict=False)
        print("[offline] 多节点平均完毕。")
    elif state_dict_path is not None:
        if state_dict_path.endswith(".pt"):
            sd = torch.load(state_dict_path, map_location="cpu")
            if isinstance(sd, dict) and "model" in sd and not any(
                k.startswith("transformer") for k in sd
            ):
                sd = sd["model"]
            model.load_state_dict(sd, strict=False)
        else:
            # 目录既可能是 HF 导出目录，也可能是原始 checkpoint 目录（含 flat_model_state_dict.pt）
            if os.path.isdir(state_dict_path):
                try:
                    ckpt_path = _resolve_ckpt_file(state_dict_path)
                    if ckpt_path.endswith(".safetensors"):
                        from safetensors.torch import load_file as _load_safetensors
                        sd = _load_safetensors(ckpt_path, device="cpu")
                    else:
                        sd = torch.load(ckpt_path, map_location="cpu")
                    if isinstance(sd, dict) and "model" in sd and not any(
                        k.startswith("transformer") for k in sd
                    ):
                        sd = sd["model"]
                    model.load_state_dict(sd, strict=False)
                except Exception:
                    # 回退到 HF 目录加载
                    model, tokenizer = build_diffugpt_model_and_tokenizer(state_dict_path)
            else:
                model, tokenizer = build_diffugpt_model_and_tokenizer(state_dict_path)

    model = model.to(device).eval()

    dynfuse_state = None
    if dynfuse_bundle_path is not None:
        try:
            from open_diloco.diloco_fusion import (
                load_dynfuse_offline_bundle,
                attach_offline_dynfuse_to_model,
            )
            dynfuse_state = load_dynfuse_offline_bundle(dynfuse_bundle_path, device=device)
            attach_offline_dynfuse_to_model(model, dynfuse_state)
            print(f"[offline] 已加载并挂载 DynFuse 离线 router: {dynfuse_bundle_path}")
        except Exception as e:
            print(f"[offline] 警告：DynFuse bundle 加载失败，将作为普通模型运行。原因: {e}")
            dynfuse_state = None

    return model, tokenizer, dynfuse_state


import contextlib


@contextlib.contextmanager
def _capture_log_results(out_dict: dict):
    """临时替换 log_benchmark_result，将结果同时写入 out_dict 并保留磁盘日志。"""
    import sys as _sys
    _module = _sys.modules[__name__]
    _orig = _module.log_benchmark_result

    def _capturing(task_name, result_dict, log_file=None):
        out_dict[task_name] = dict(result_dict)
        _orig(task_name, result_dict, log_file)

    _module.log_benchmark_result = _capturing
    try:
        yield out_dict
    finally:
        _module.log_benchmark_result = _orig


@contextlib.contextmanager
def _inject_dynfuse(dynfuse_state):
    """临时将 generate_samples / eval_forward 替换为携带 dynfuse_state 的版本。

    基准函数（eval_Lambada / eval_hellaswag 等）在本文件内以模块全局名字调用
    generate_samples / eval_forward，猴子补丁替换这两个全局名字后，
    所有基准任务的 forward 路径都会自动触发 DynFuse router。
    """
    import sys as _sys
    _module = _sys.modules[__name__]

    if dynfuse_state is None:
        yield
        return

    _orig_gs  = _module.generate_samples
    _orig_gsv2 = _module.generate_samples_v2
    _orig_ef  = _module.eval_forward

    def _gs_wrapped(model_, diff_args, tokenizer_, inputs,
                    eval=False, gsm=False, dynfuse_state=None, **kw):
        # 始终注入外部 dynfuse_state（忽略传入的 None）
        return _orig_gs(model_, diff_args, tokenizer_, inputs,
                        eval, gsm, dynfuse_state=dynfuse_state or _inject_dynfuse._active_state, **kw)

    def _gsv2_wrapped(model_, diff_args, tokenizer_, inputs,
                      eval=False, dynfuse_state=None, **kw):
        return _orig_gsv2(model_, diff_args, tokenizer_, inputs,
                          eval, dynfuse_state=dynfuse_state or _inject_dynfuse._active_state, **kw)

    def _ef_wrapped(model_, inputs_, diff_args, tokenizer_, dynfuse_state=None, **kw):
        return _orig_ef(model_, inputs_, diff_args, tokenizer_,
                        dynfuse_state=dynfuse_state or _inject_dynfuse._active_state, **kw)

    _inject_dynfuse._active_state = dynfuse_state
    _module.generate_samples  = _gs_wrapped
    _module.generate_samples_v2 = _gsv2_wrapped
    _module.eval_forward      = _ef_wrapped
    try:
        yield
    finally:
        _module.generate_samples  = _orig_gs
        _module.generate_samples_v2 = _orig_gsv2
        _module.eval_forward      = _orig_ef
        _inject_dynfuse._active_state = None


_inject_dynfuse._active_state = None  # 模块级初始化


def eval_all_tasks(
    model,
    tokenizer,
    args,
    dynfuse_state=None,
    label: str = "",
    skip_on_error: bool = True,
) -> dict:
    """对给定模型运行全部下游基准测试，返回 {task_name: metrics_dict}。

    参数
    ----
    model, tokenizer : 已加载并在 device 上的模型与分词器。
    args             : 与 main() 中相同的 argparse Namespace（含 diffusion_steps / logits_temp 等）。
    dynfuse_state    : 若不为 None，则通过 _inject_dynfuse 上下文为所有基准任务注入
                       时间步感知 router（generate_samples / eval_forward 均覆盖）。
    label            : 仅用于日志前缀，区分 "ours" / "full"。
    skip_on_error    : True 时单个任务出错跳过，False 时直接抛出。
    """
    results: dict = {}

    tasks = [
        ("lambada",       lambda: eval_Lambada(model, tokenizer, args)),
        ("hellaswag",     lambda: eval_hellaswag(model, tokenizer, args)),
        ("humaneval",     lambda: humaneval_infill(model, tokenizer, args)),
        ("roc_infilling", lambda: eval_infilling(model, tokenizer, args)),
        ("wino",          lambda: eval_wino(model, tokenizer, args)),
        ("siqa",          lambda: eval_siqa(model, tokenizer, args)),
        ("piqa",          lambda: eval_piqa(model, tokenizer, args)),
        ("squad",         lambda: eval_squad(model, tokenizer, args)),
        ("triviaqa",      lambda: eval_triviaqa(model, tokenizer, args)),
        ("gen_ppl",       lambda: eval_unconditional_generation(
                              model, tokenizer, args, args.gpt2_large_path)),
    ]
    if getattr(args, "gsm8k_path", None):
        tasks.append(("gsm8k", lambda: eval_gsm8k(model, tokenizer, args)))

    with _capture_log_results(results), _inject_dynfuse(dynfuse_state):
        for task_name, task_fn in tasks:
            print(f"\n{'='*55}")
            print(f"[eval_all_tasks] {label} → {task_name}")
            print(f"{'='*55}")
            try:
                out = task_fn()
                if isinstance(out, dict):
                    # 优先使用函数返回值，避免日志 task_name 与统一键名不一致
                    results[task_name] = dict(out)
            except Exception as exc:
                print(f"[eval_all_tasks] {label} {task_name} 出错: {exc}")
                if not skip_on_error:
                    raise
                results.setdefault(task_name, {"error": str(exc)})

    return results


def _compute_dynfuse_extra_params(dynfuse_state) -> dict:
    """统计 DynFuse 额外参数（router + LoRA）。"""
    if dynfuse_state is None:
        return {
            "extra_params_total": 0,
            "extra_params_router": 0,
            "extra_params_lora": 0,
            "extra_params_million": 0.0,
        }
    router_params = sum(p.numel() for p in dynfuse_state.router.parameters())
    lora_params = 0
    for blk in dynfuse_state.block_lora_consensus.values():
        for A, B in blk.values():
            lora_params += A.numel() + B.numel()
    for blk in dynfuse_state.block_lora.values():
        for A, B in blk.values():
            lora_params += A.numel() + B.numel()
    total = router_params + lora_params
    return {
        "extra_params_total": int(total),
        "extra_params_router": int(router_params),
        "extra_params_lora": int(lora_params),
        "extra_params_million": float(total / 1e6),
    }


@torch.no_grad()
def _measure_inference_latency(
    model,
    tokenizer,
    dynfuse_state=None,
    *,
    warmup_runs: int = 3,
    bench_runs: int = 10,
    batch_size: int = 1,
    seq_len: int = 128,
    sampling_eps: float = 1e-3,
    anneal_steps: int = 1,
    shift: bool = True,
) -> dict:
    """用 compute_diffusion_loss 做统一 latency 基准，返回 ms/iter 与 tokens/sec。"""
    model.eval()
    dev = next(model.parameters()).device
    model_ref = model.module if hasattr(model, "module") else model
    vocab_size = int(model_ref.vocab_size)

    # 构造固定随机输入，避免数据加载噪声影响 latency
    x = torch.randint(0, max(vocab_size - 1, 2), (batch_size, seq_len), device=dev, dtype=torch.long)
    batch = {"input_ids": x}

    use_autocast = torch.cuda.is_available()
    autocast_ctx = (
        torch.autocast(device_type="cuda", dtype=torch.bfloat16)
        if use_autocast else nullcontext()
    )

    def _run_once():
        with autocast_ctx:
            _ = compute_diffusion_loss(
                model=model,
                batch=batch,
                tokenizer=tokenizer,
                global_step=999999,
                anneal_steps=max(anneal_steps, 1),
                shift=shift,
                sampling_eps=sampling_eps,
                return_stats=False,
                dynfuse_state=dynfuse_state,
            )

    for _ in range(max(warmup_runs, 0)):
        _run_once()

    if torch.cuda.is_available():
        torch.cuda.synchronize(dev)
    t0 = time.perf_counter()
    for _ in range(max(bench_runs, 1)):
        _run_once()
    if torch.cuda.is_available():
        torch.cuda.synchronize(dev)
    t1 = time.perf_counter()

    elapsed = max(t1 - t0, 1e-9)
    iters = max(bench_runs, 1)
    sec_per_iter = elapsed / iters
    tokens_per_iter = batch_size * seq_len
    tps = float(tokens_per_iter / sec_per_iter)
    return {
        "latency_ms_per_iter": float(sec_per_iter * 1000.0),
        "tokens_per_sec": tps,
        "batch_size": int(batch_size),
        "seq_len": int(seq_len),
        "bench_runs": int(iters),
    }


def compare_two_checkpoints(args):
    # ── 加载 ours 模型（支持多节点平均 + DynFuse 离线 router）────────────
    ours_node_dicts = _parse_csv(getattr(args, "node_state_dicts", None))
    ours_dynfuse_bundle = getattr(args, "ours_dynfuse_bundle", None)

    ours_model, ours_tok, ours_dynfuse = _load_model_with_dynfuse(
        base_model_path=args.base_model_path,
        state_dict_path=args.ours_state_dict if not ours_node_dicts else None,
        node_state_dicts=ours_node_dicts if ours_node_dicts else None,
        dynfuse_bundle_path=ours_dynfuse_bundle,
    )
    # ── 加载 full 模型（支持多节点平均，与 ours 共用同一批原始节点权重，保证对比公平）──
    full_node_dicts = _parse_csv(getattr(args, "full_node_state_dicts", None))
    full_model, full_tok, _ = _load_model_with_dynfuse(
        base_model_path=args.base_model_path,
        state_dict_path=args.full_state_dict if not full_node_dicts else None,
        node_state_dicts=full_node_dicts if full_node_dicts else None,
        dynfuse_bundle_path=None,
    )

    max_rows = args.val_max_batches * args.batch_size * 4
    result = {
        "ours_state_dict": args.ours_state_dict,
        "full_state_dict": args.full_state_dict,
        "base_model_path": args.base_model_path,
    }
    result["extra_params"] = {
        "ours": _compute_dynfuse_extra_params(ours_dynfuse),
        "full": _compute_dynfuse_extra_params(None),
    }

    mixed_paths = _parse_csv(args.mixed_val_paths)
    mixed_weights = _parse_csv_floats(args.mixed_val_weights)
    if mixed_paths:
        mixed_ds = _build_eval_dataset(mixed_paths, mixed_weights, max_rows=max_rows)
        ours_mixed = _evaluate_loss_ppl(
            ours_model, ours_tok, mixed_ds,
            batch_size=args.batch_size,
            val_max_batches=args.val_max_batches,
            shift=args.shift,
            sampling_eps=args.sampling_eps,
            anneal_steps=args.anneal_steps,
            dynfuse_state=ours_dynfuse,
        )
        full_mixed = _evaluate_loss_ppl(
            full_model, full_tok, mixed_ds,
            batch_size=args.batch_size,
            val_max_batches=args.val_max_batches,
            shift=args.shift,
            sampling_eps=args.sampling_eps,
            anneal_steps=args.anneal_steps,
            dynfuse_state=None,
        )
        result["mixed"] = {"ours": ours_mixed, "full": full_mixed}

    domain_names = _parse_csv(args.domain_names)
    domain_paths = _parse_csv(args.domain_paths)
    if domain_names and domain_paths and len(domain_names) == len(domain_paths):
        result["domains"] = {}
        for name, path in zip(domain_names, domain_paths):
            ds = _build_eval_dataset([path], None, max_rows=max_rows)
            ours_metrics = _evaluate_loss_ppl(
                ours_model, ours_tok, ds,
                batch_size=args.batch_size,
                val_max_batches=args.val_max_batches,
                shift=args.shift,
                sampling_eps=args.sampling_eps,
                anneal_steps=args.anneal_steps,
                dynfuse_state=ours_dynfuse,
            )
            full_metrics = _evaluate_loss_ppl(
                full_model, full_tok, ds,
                batch_size=args.batch_size,
                val_max_batches=args.val_max_batches,
                shift=args.shift,
                sampling_eps=args.sampling_eps,
                anneal_steps=args.anneal_steps,
                dynfuse_state=None,
            )
            result["domains"][name] = {"ours": ours_metrics, "full": full_metrics}

    # ── 主判断指标：val_masked_ce（纯语言建模CE，不受扩散采样项干扰）──
    # val_loss 也保留，但仅作辅助；论文主指标用 val_masked_ce
    PRIMARY = "val_masked_ce"

    # ── Macro 平均 + 胜负统计 ──────────────────────────────────────────
    macro_summary: dict = {}
    domain_names_list = list(result.get("domains", {}).keys())
    if domain_names_list:
        ours_ce_vals, full_ce_vals = [], []
        win_count = tie_count = loss_count = 0
        TIE_EPS = 0.001  # |delta| < 0.001 视为 tie

        for dname, dres in result["domains"].items():
            o_ce = dres["ours"].get(PRIMARY, float("nan"))
            f_ce = dres["full"].get(PRIMARY, float("nan"))
            ours_ce_vals.append(o_ce)
            full_ce_vals.append(f_ce)
            delta = o_ce - f_ce
            if abs(delta) < TIE_EPS:
                tie_count += 1
            elif delta < 0:
                win_count += 1   # ours 更低 = 更好
            else:
                loss_count += 1

        macro_ours = sum(ours_ce_vals) / len(ours_ce_vals)
        macro_full = sum(full_ce_vals) / len(full_ce_vals)
        macro_delta = macro_ours - macro_full

        macro_summary = {
            "macro_avg_ours_ce":   macro_ours,
            "macro_avg_full_ce":   macro_full,
            "macro_delta_ce":      macro_delta,       # <0 = ours 整体更好
            "domain_win_count":    win_count,
            "domain_tie_count":    tie_count,
            "domain_loss_count":   loss_count,
            "total_domains":       len(domain_names_list),
            "verdict": "OURS_BETTER" if macro_delta < -TIE_EPS
                       else ("TIED" if abs(macro_delta) <= TIE_EPS else "FULL_BETTER"),
        }
        result["macro_summary"] = macro_summary


        # ── Worst-domain + Domain gap（论文主指标）────────────────────
        # 对每个指标分别计算：
        #   macro_avg      = 各 domain 简单平均，避免 mixed val 被大域/容易域掩盖
        #   worst_domain   = loss / ppl 最大的 domain，数值越低越好
        #   domain_gap     = worst_domain - macro_avg，越小表示域间不均衡越弱
        #   delta          = ours - full，<0 表示 ours 更好
        offline_summary: dict = {}

        def _safe_values(metric_name: str, side: str):
            vals = []
            per_domain = {}
            for _dname, _dres in result["domains"].items():
                v = _dres.get(side, {}).get(metric_name, float("nan"))
                if isinstance(v, (int, float)) and math.isfinite(v):
                    vals.append((float(v), _dname))
                    per_domain[_dname] = float(v)
            return vals, per_domain

        for metric_name in ["val_masked_ce", "val_masked_ce_ppl", "val_loss", "val_ppl"]:
            ours_vals, ours_per_domain = _safe_values(metric_name, "ours")
            full_vals, full_per_domain = _safe_values(metric_name, "full")
            if not ours_vals or not full_vals:
                continue

            ours_avg = sum(v for v, _ in ours_vals) / len(ours_vals)
            full_avg = sum(v for v, _ in full_vals) / len(full_vals)
            ours_worst_val, ours_worst_domain = max(ours_vals, key=lambda x: x[0])
            full_worst_val, full_worst_domain = max(full_vals, key=lambda x: x[0])
            ours_gap = ours_worst_val - ours_avg
            full_gap = full_worst_val - full_avg

            # 每域 delta：ours - full，<0 表示 ours 在该域更好
            per_domain_delta = {
                d: ours_per_domain[d] - full_per_domain[d]
                for d in ours_per_domain.keys() & full_per_domain.keys()
            }

            offline_summary[metric_name] = {
                "ours_macro_avg": ours_avg,
                "full_macro_avg": full_avg,
                "delta_macro_avg": ours_avg - full_avg,
                "ours_worst_domain": ours_worst_domain,
                "ours_worst_value": ours_worst_val,
                "full_worst_domain": full_worst_domain,
                "full_worst_value": full_worst_val,
                "delta_worst_value": ours_worst_val - full_worst_val,
                "ours_domain_gap": ours_gap,
                "full_domain_gap": full_gap,
                "delta_domain_gap": ours_gap - full_gap,
                "per_domain_delta": per_domain_delta,
            }

        if offline_summary:
            result["offline_summary"] = offline_summary

    # ── 下游基准任务成对评测（论文副表：GenPPL / Distinct-2 / Lambada / HellaSwag / HumanEval …）──
    run_benchmarks = getattr(args, "run_benchmarks", False)
    if run_benchmarks:
        print("\n" + "=" * 60)
        print("[compare_two_checkpoints] 开始对 OURS 模型跑下游基准…")
        print("=" * 60)
        ours_bench = eval_all_tasks(ours_model, ours_tok, args,
                                     dynfuse_state=ours_dynfuse, label="ours")
        print("\n" + "=" * 60)
        print("[compare_two_checkpoints] 开始对 FULL 模型跑下游基准…")
        print("=" * 60)
        full_bench = eval_all_tasks(full_model, full_tok, args,
                                     dynfuse_state=None, label="full")
        result["benchmarks"] = {"ours": ours_bench, "full": full_bench}

        # 打印成对对比表
        print("\n" + "=" * 60)
        print("【下游基准对比：ours vs full】")
        all_tasks = sorted(set(list(ours_bench.keys()) + list(full_bench.keys())))
        for task in all_tasks:
            o = ours_bench.get(task, {})
            f = full_bench.get(task, {})
            o_str = "  ".join(f"{k}={v:.4f}" for k, v in o.items() if isinstance(v, float))
            f_str = "  ".join(f"{k}={v:.4f}" for k, v in f.items() if isinstance(v, float))
            print(f"  [{task}]  ours: {o_str or o}  full: {f_str or f}")
        print("=" * 60 + "\n")

    # ── 额外开销：latency / throughput（统一基准）────────────────────────
    if getattr(args, "measure_latency", False):
        ours_lat = _measure_inference_latency(
            ours_model, ours_tok, dynfuse_state=ours_dynfuse,
            warmup_runs=args.latency_warmup_runs,
            bench_runs=args.latency_bench_runs,
            batch_size=args.latency_batch_size,
            seq_len=args.latency_seq_len,
            sampling_eps=args.sampling_eps,
            anneal_steps=args.anneal_steps,
            shift=args.shift,
        )
        full_lat = _measure_inference_latency(
            full_model, full_tok, dynfuse_state=None,
            warmup_runs=args.latency_warmup_runs,
            bench_runs=args.latency_bench_runs,
            batch_size=args.latency_batch_size,
            seq_len=args.latency_seq_len,
            sampling_eps=args.sampling_eps,
            anneal_steps=args.anneal_steps,
            shift=args.shift,
        )
        overhead = {}
        if full_lat["latency_ms_per_iter"] > 0:
            overhead["latency_overhead_ratio"] = (
                ours_lat["latency_ms_per_iter"] / full_lat["latency_ms_per_iter"] - 1.0
            )
        if full_lat["tokens_per_sec"] > 0:
            overhead["throughput_drop_ratio"] = (
                1.0 - ours_lat["tokens_per_sec"] / full_lat["tokens_per_sec"]
            )
        result["latency"] = {"ours": ours_lat, "full": full_lat, "overhead": overhead}

    # ── 终端打印 ──────────────────────────────────────────────────────
    print(json.dumps(result, ensure_ascii=False, indent=2))

    if macro_summary:
        verdict_str = {
            "OURS_BETTER": "✅ OURS 整体更好",
            "FULL_BETTER": "❌ FULL MERGE 更好",
            "TIED":        "⚖️  基本持平",
        }.get(macro_summary["verdict"], macro_summary["verdict"])

        print("\n" + "=" * 60)
        print(f"【主指标 val_masked_ce 总结（判断依据）】")
        print(f"  Macro avg  ours={macro_summary['macro_avg_ours_ce']:.4f}  "
              f"full={macro_summary['macro_avg_full_ce']:.4f}  "
              f"delta={macro_summary['macro_delta_ce']:+.4f}")
        print(f"  域胜负：win={macro_summary['domain_win_count']}  "
              f"tie={macro_summary['domain_tie_count']}  "
              f"loss={macro_summary['domain_loss_count']}  "
              f"/ {macro_summary['total_domains']} 域")
        print(f"  结论：{verdict_str}")
        print("=" * 60 + "\n")

    if result.get("offline_summary"):
        print("\n" + "=" * 60)
        print("【离线分域鲁棒性指标：Worst-domain / Domain gap】")
        for metric_name in ["val_masked_ce", "val_masked_ce_ppl", "val_loss", "val_ppl"]:
            if metric_name not in result["offline_summary"]:
                continue
            m = result["offline_summary"][metric_name]
            print(
                f"  {metric_name}: "
                f"worst ours={m['ours_worst_value']:.4f}({m['ours_worst_domain']})  "
                f"full={m['full_worst_value']:.4f}({m['full_worst_domain']})  "
                f"delta={m['delta_worst_value']:+.4f};  "
                f"gap ours={m['ours_domain_gap']:.4f}  "
                f"full={m['full_domain_gap']:.4f}  "
                f"delta_gap={m['delta_domain_gap']:+.4f}"
            )
        print("=" * 60 + "\n")

    if args.output_json:
        with open(args.output_json, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)

    # ── Wandb ──────────────────────────────────────────────────────────
    if args.log_wandb:
        if wandb is None:
            raise RuntimeError("log_wandb=True 但当前环境未安装 wandb")
        run_name = args.wandb_run_name or f"ckpt-compare-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        # 同一 wandb run：两次评估（如 step 200 / 400）用相同的 --wandb-run-id + resume="allow"
        init_kw: dict = dict(
            project=args.wandb_project,
            entity=args.wandb_entity,
            name=run_name,
            mode=args.wandb_mode,
            config={
                "ours_state_dict": args.ours_state_dict,
                "full_state_dict": args.full_state_dict,
                "base_model_path": args.base_model_path,
                "mixed_val_paths": args.mixed_val_paths,
                "mixed_val_weights": args.mixed_val_weights,
                "domain_names": args.domain_names,
                "val_max_batches": args.val_max_batches,
                "batch_size": args.batch_size,
            },
        )
        if args.wandb_run_id:
            init_kw["id"] = args.wandb_run_id
            init_kw["resume"] = "allow"
        wb_run = wandb.init(**init_kw)
        wb_payload: dict = {}

        # ── 1. 混合总体 ─────────────────────────────────────────────
        if "mixed" in result:
            ours_m = result["mixed"].get("ours", {})
            full_m = result["mixed"].get("full", {})
            for k in ["val_loss", "val_masked_ce", "val_masked_ce_ppl"]:
                if k in ours_m:
                    wb_payload[f"mixed/ours/{k}"] = ours_m[k]
                if k in full_m:
                    wb_payload[f"mixed/full/{k}"] = full_m[k]
                if k in ours_m and k in full_m:
                    wb_payload[f"mixed/delta/{k}"] = ours_m[k] - full_m[k]  # <0=ours好

        # ── 2. 分域标量（每域一条，ours/full/delta） ─────────────────
        if "domains" in result:
            for dname, dres in result["domains"].items():
                ours_d = dres.get("ours", {})
                full_d = dres.get("full", {})
                for k in ["val_masked_ce", "val_masked_ce_ppl", "val_loss"]:
                    if k in ours_d:
                        wb_payload[f"domain/{dname}/ours/{k}"] = ours_d[k]
                    if k in full_d:
                        wb_payload[f"domain/{dname}/full/{k}"] = full_d[k]
                    if k in ours_d and k in full_d:
                        wb_payload[f"domain/{dname}/delta/{k}"] = ours_d[k] - full_d[k]

        # ── 3. Macro 汇总 ────────────────────────────────────────────
        if macro_summary:
            wb_payload["macro/ours/val_masked_ce"]  = macro_summary["macro_avg_ours_ce"]
            wb_payload["macro/full/val_masked_ce"]  = macro_summary["macro_avg_full_ce"]
            wb_payload["macro/delta/val_masked_ce"] = macro_summary["macro_delta_ce"]
            wb_payload["macro/win_count"]   = macro_summary["domain_win_count"]
            wb_payload["macro/tie_count"]   = macro_summary["domain_tie_count"]
            wb_payload["macro/loss_count"]  = macro_summary["domain_loss_count"]

        # ── 3.5 Worst-domain / Domain gap 汇总，主论文指标 ─────────────
        if result.get("offline_summary"):
            for metric_name, m in result["offline_summary"].items():
                prefix = f"offline_summary/{metric_name}"
                wb_payload[f"{prefix}/ours_macro_avg"] = m["ours_macro_avg"]
                wb_payload[f"{prefix}/full_macro_avg"] = m["full_macro_avg"]
                wb_payload[f"{prefix}/delta_macro_avg"] = m["delta_macro_avg"]
                wb_payload[f"{prefix}/ours_worst_value"] = m["ours_worst_value"]
                wb_payload[f"{prefix}/full_worst_value"] = m["full_worst_value"]
                wb_payload[f"{prefix}/delta_worst_value"] = m["delta_worst_value"]
                wb_payload[f"{prefix}/ours_domain_gap"] = m["ours_domain_gap"]
                wb_payload[f"{prefix}/full_domain_gap"] = m["full_domain_gap"]
                wb_payload[f"{prefix}/delta_domain_gap"] = m["delta_domain_gap"]

        # ── 3.6 下游基准成对对比（论文副表） ────────────────────────────
        if result.get("benchmarks"):
            ours_b = result["benchmarks"].get("ours", {})
            full_b = result["benchmarks"].get("full", {})
            for task in set(list(ours_b.keys()) + list(full_b.keys())):
                o_metrics = ours_b.get(task, {})
                f_metrics = full_b.get(task, {})
                for k in set(list(o_metrics.keys()) + list(f_metrics.keys())):
                    o_v = o_metrics.get(k)
                    f_v = f_metrics.get(k)
                    if isinstance(o_v, (int, float)):
                        wb_payload[f"bench/{task}/ours/{k}"] = float(o_v)
                    if isinstance(f_v, (int, float)):
                        wb_payload[f"bench/{task}/full/{k}"] = float(f_v)
                    if isinstance(o_v, (int, float)) and isinstance(f_v, (int, float)):
                        wb_payload[f"bench/{task}/delta/{k}"] = float(o_v) - float(f_v)

            # 论文副表（Table artifact）
            if not args.wandb_minimal:
                bench_cols = ["task", "metric", "ours", "full", "delta"]
                bench_rows = []
                for task in sorted(set(list(ours_b.keys()) + list(full_b.keys()))):
                    o_metrics = ours_b.get(task, {})
                    f_metrics = full_b.get(task, {})
                    for k in sorted(set(list(o_metrics.keys()) + list(f_metrics.keys()))):
                        o_v = o_metrics.get(k, float("nan"))
                        f_v = f_metrics.get(k, float("nan"))
                        if not isinstance(o_v, (int, float)):
                            o_v = float("nan")
                        if not isinstance(f_v, (int, float)):
                            f_v = float("nan")
                        delta = o_v - f_v if (o_v == o_v and f_v == f_v) else float("nan")
                        bench_rows.append([task, k, round(o_v, 4), round(f_v, 4), round(delta, 4)])
                if bench_rows:
                    bench_tbl = wandb.Table(columns=bench_cols, data=bench_rows)
                    step = args.eval_step if args.eval_step is not None else 0
                    wandb.log({"benchmark_comparison_table": bench_tbl}, step=step)

        # ── 3.7 Extra Params / Latency Overhead ───────────────────────────
        if result.get("extra_params"):
            ep_o = result["extra_params"].get("ours", {})
            ep_f = result["extra_params"].get("full", {})
            for k in ["extra_params_total", "extra_params_router", "extra_params_lora", "extra_params_million"]:
                if k in ep_o:
                    wb_payload[f"overhead/extra_params/ours/{k}"] = ep_o[k]
                if k in ep_f:
                    wb_payload[f"overhead/extra_params/full/{k}"] = ep_f[k]
                if k in ep_o and k in ep_f:
                    wb_payload[f"overhead/extra_params/delta/{k}"] = ep_o[k] - ep_f[k]

        if result.get("latency"):
            lat_o = result["latency"].get("ours", {})
            lat_f = result["latency"].get("full", {})
            lat_d = result["latency"].get("overhead", {})
            for k in ["latency_ms_per_iter", "tokens_per_sec"]:
                if k in lat_o:
                    wb_payload[f"overhead/latency/ours/{k}"] = lat_o[k]
                if k in lat_f:
                    wb_payload[f"overhead/latency/full/{k}"] = lat_f[k]
                if k in lat_o and k in lat_f:
                    wb_payload[f"overhead/latency/delta/{k}"] = lat_o[k] - lat_f[k]
            for k, v in lat_d.items():
                wb_payload[f"overhead/latency/{k}"] = v

        # ── 4. 可画折线图：以 eval_step 为横轴 ──────────────────────
        step = args.eval_step if args.eval_step is not None else 0
        if wb_payload:
            wandb.log(wb_payload, step=step)

        # ── 5. Table / 柱状图（artifact 较大，网络慢时会长时间“闪烁”上传）──
        if (not args.wandb_minimal) and "domains" in result:
            cols = ["domain", "ours_ce", "full_ce", "delta_ce",
                    "ours_ppl", "full_ppl", "delta_ppl", "winner"]
            rows = []
            for dname, dres in result["domains"].items():
                o_ce = dres["ours"].get(PRIMARY, float("nan"))
                f_ce = dres["full"].get(PRIMARY, float("nan"))
                o_ppl = dres["ours"].get("val_masked_ce_ppl", float("nan"))
                f_ppl = dres["full"].get("val_masked_ce_ppl", float("nan"))
                delta = o_ce - f_ce
                delta_ppl = o_ppl - f_ppl
                winner = "ours" if delta < -0.001 else ("full" if delta > 0.001 else "tie")
                rows.append([dname, round(o_ce, 4), round(f_ce, 4), round(delta, 4),
                             round(o_ppl, 4), round(f_ppl, 4), round(delta_ppl, 4), winner])
            tbl = wandb.Table(columns=cols, data=rows)
            wandb.log({"domain_comparison_table": tbl}, step=step)

            bar_data = [[r[0], r[1], r[2]] for r in rows]
            bar_tbl = wandb.Table(columns=["domain", "ours_ce", "full_ce"], data=bar_data)
            wandb.log({
                "domain_ce_bar": wandb.plot.bar(
                    bar_tbl, "domain", "ours_ce", title="val_masked_ce ours vs full (per domain)"
                )
            }, step=step)

        wb_run.finish()

def top_p_logits(logits, p=0.9):
    sorted_logits, sorted_indices = torch.sort(logits, descending=True)
    # import pdb; pdb.set_trace();
    cumulative_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)

    # Remove tokens with cumulative probability above the threshold
    sorted_indices_to_remove = cumulative_probs > p
    # Shift the indices to the right to keep the first token above the threshold
    sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
    sorted_indices_to_remove[..., 0] = 0

    mask = torch.zeros_like(logits, dtype=torch.bool, device=logits.device)
    mask = mask.scatter_(-1, sorted_indices, sorted_indices_to_remove)
    logits = logits.masked_fill(mask, torch.finfo(logits.dtype).min)
    return logits

def eval_Lambada(model, tokenizer, args):

    print("Lambada progress:")
    total_cnt = 0
    cor = 0
    with open('/mnt/24-scale/LLaMA_Factory/evaluation/evaluation/lambada_test_plain_text.txt', 'r', encoding='utf-8') as file:
        for line in file:
            total_cnt += 1
            line = line.strip()
            # import pdb; pdb.set_trace();
            x0 = tokenizer.encode(line)
            prefix = tokenizer.encode(' '.join(line.split()[:-1]))
            # attention_mask = get_anneal_attn_mask(len(xt), 1, dtype=model.lm_head.weight.dtype, device=model.device, attn_mask_ratio=1.0)
            # masked_nums = len(xt)-len(inputs)
            # xt[-masked_nums:] = [tokenizer.mask_token_id] * masked_nums
            # xt = torch.tensor([xt]).to(model.device)
            # logits = model(xt, attention_mask=attention_mask)
            # filter_logits = top_p_logits(logits/0.8, p=0.8)
            # scores = torch.log_softmax(filter_logits, dim=-1)
            # # x0_scores, x0 = scores.max(-1)
            # x0 = dists.Categorical(logits=scores).sample()
            # pred = tokenizer.decode(x0.tolist()[0][-masked_nums-1:-1])

            masked_nums = len(x0)-len(prefix)
            src_mask = [1]*len(prefix)+[0]*masked_nums
            inputs = {"input_ids": torch.tensor([x0]), "src_mask": torch.tensor([src_mask])}
            args.diffusion_steps = masked_nums
            args.logits_temp = 1.0
            res = generate_samples(model, args, tokenizer, inputs, eval=True)
            pred = tokenizer.decode(res.tolist()[0][-masked_nums:])
            # import pdb; pdb.set_trace();
            if pred.strip() == line.split()[-1].strip():
                cor += 1
            # print(total_cnt, cor/total_cnt)
    print('Lambada acc:', cor/total_cnt)
    log_benchmark_result("lambada", {"acc": cor/total_cnt})

import re
import numpy as np

def preprocess(text):
    text = text.strip()
    # NOTE: Brackets are artifacts of the WikiHow dataset portion of HellaSwag.
    text = text.replace(" [title]", ". ")
    text = re.sub("\\[.*?\\]", "", text)
    text = text.replace("  ", " ")
    return text

def eval_hellaswag(model, tokenizer, args):
    print("eval_hellaswag progress:")
    from datasets import load_dataset
    # ds = load_dataset("Rowan/hellaswag", split='validation')
    # ds = load_dataset(
    #     "parquet",
    #     data_files="/mnt/dataset/test_dataset/hellaswag/*.parquet",
    #     split='train',
    # )
    ds = load_dataset(
        "parquet",
        data_files={"validation": "/mnt/dataset/test_dataset/hellaswag/validation-00000-of-00001.parquet"},
        split="validation",
    )
    total_cnt = 0
    cor = 0
    for doc in ds:
        total_cnt += 1
        ctx = doc["ctx_a"] + " " + doc["ctx_b"].capitalize()

        query = preprocess(doc["activity_label"] + ": " + ctx)
        choices = [preprocess(ending) for ending in doc["endings"]]
        gold = int(doc["label"])

        score_list = []
        prefix = tokenizer.encode(query)

        for choice in choices:

            x0 = prefix + tokenizer.encode(choice)
            src_mask = [1]*len(prefix)+[0]*(len(x0)-len(prefix))
            inputs = {"input_ids": torch.tensor([x0]), "src_mask": torch.tensor([src_mask])}
            score = eval_forward(model, inputs, args, tokenizer)
            # import pdb; pdb.set_trace();
            score_list.append(score.tolist())
        pred = np.argmin(np.array(score_list))

        if pred == gold:
            cor += 1
        # print(total_cnt, cor/total_cnt)
        # if total_cnt % 2000 == 0:
        #     print("hellaswag", total_cnt, cor / total_cnt)
        if total_cnt == 2000:
            break
    print('hellaswag acc:', cor/total_cnt)
    log_benchmark_result("hellaswag", {"acc": cor/total_cnt})


def eval_wino(model, tokenizer, args):
    from datasets import load_dataset
    print("wino progress:")
    # ds = load_dataset("allenai/winogrande", "winogrande_xl", split='validation', trust_remote_code=True)
    ds = load_dataset(
        "parquet",
        data_files="/mnt/dataset/test_dataset/winogrande/data/*.parquet",
        split='train',
        trust_remote_code=True
    )
    total_cnt = 0
    cor = 0

    for doc in ds:
        total_cnt += 1
        
        idx = doc["sentence"].index("_")
        
        options = [doc["option1"], doc["option2"]]

        answer_to_num = {"1": 0, "2": 1}
        gold = answer_to_num[doc["answer"]]

        score_list = []
        
        for opt in options:
            target = opt 
            suffix = doc["sentence"][idx+1:].strip()
            target_id = tokenizer.encode(target, add_special_tokens=False)
            suffix_id = tokenizer.encode(suffix, add_special_tokens=False)
            prefix = doc["sentence"][:idx]
            prefix_id = tokenizer.encode(prefix, add_special_tokens=False)

            x0 = prefix_id + target_id + suffix_id
            src_mask = [1]*len(prefix_id)+[0]*(len(x0)-len(prefix_id))
            inputs = {"input_ids": torch.tensor([x0]), "src_mask": torch.tensor([src_mask])}
            score = eval_forward(model, inputs, args, tokenizer)
            # import pdb; pdb.set_trace();
            score_list.append(score.tolist())
        pred = np.argmin(np.array(score_list))

        if pred == gold:
            cor += 1
        # print(total_cnt, cor/total_cnt)
        
    print('wino acc:', cor/total_cnt)
    log_benchmark_result("wino", {"acc": cor/total_cnt})

from datasets import load_dataset
def eval_piqa(model, tokenizer, args):
    print("pipa process:")
    # ds = load_dataset("ybisk/piqa", split='validation', trust_remote_code=True)
    # ds = load_dataset("/mnt/dataset/test_dataset/piqa", split="validation", trust_remote_code=True)
    data_path = "/mnt/dataset/test_dataset/piqa/dev.jsonl"
    label_path = "/mnt/dataset/test_dataset/piqa/dev-labels.lst"

    ds = []
    with open(data_path, "r", encoding="utf-8") as f_data, open(label_path, "r", encoding="utf-8") as f_label:
        # labels = [line.strip() for line in f_label]
        labels = [int(line.strip()) for line in f_label]
        for i, line in enumerate(f_data):
            obj = json.loads(line)
            obj["label"] = labels[i]
            ds.append(obj)

    total_cnt = 0
    cor = 0
    for doc in ds:
        total_cnt += 1
        query = f"Question: {doc['goal']}\nAnswer: "
        choices = [doc["sol1"], doc["sol2"]]
        gold = doc["label"]
        score_list = []
        prefix = tokenizer.encode(query)
        for choice in choices:
            x0 = prefix + tokenizer.encode(" " + choice)
            src_mask = [1]*len(prefix)+[0]*(len(x0)-len(prefix))
            inputs = {"input_ids": torch.tensor([x0]), "src_mask": torch.tensor([src_mask])}
            score = eval_forward(model, inputs, args, tokenizer)
            # import pdb; pdb.set_trace();
            score_list.append(score.tolist())
        pred = np.argmin(np.array(score_list))
        if pred == gold:
            cor += 1
        # print(total_cnt, cor/total_cnt)
    print('pipa acc:', cor/total_cnt)
    log_benchmark_result("piqa", {"acc": cor/total_cnt})


from datasets import load_dataset
    # ds = load_dataset("allenai/social_i_qa", split='validation', trust_remote_code=True)
    # ds = load_dataset("/mnt/dataset/test_dataset/social_i_qa/social_i_qa.py", split="validation", trust_remote_code=True)
def eval_siqa(model, tokenizer, args):
    print("siqa,process:")
    data_path = "/mnt/dataset/test_dataset/social_i_qa/dev.jsonl"
    label_path = "/mnt/dataset/test_dataset/social_i_qa/dev-labels.lst"

    ds = []
    with open(data_path, "r", encoding="utf-8") as f_data, open(label_path, "r", encoding="utf-8") as f_label:
        labels = [line.strip() for line in f_label]
        for i, line in enumerate(f_data):
            obj = json.loads(line)
            obj["label"] = labels[i]
            ds.append(obj)
    total_cnt = 0
    cor = 0
    for doc in ds:
        total_cnt += 1
        query = f"Question: {doc['context']} {doc['question']}\nAnswer: "
        choices = [doc['answerA'], doc['answerB'], doc['answerC']]
        gold = int(doc["label"]) - 1
        score_list = []
        prefix = tokenizer.encode(query, add_special_tokens=False)
        for choice in choices:
            x0 = prefix + tokenizer.encode(choice, add_special_tokens=False)
            src_mask = [1]*len(prefix)+[0]*(len(x0)-len(prefix))
            inputs = {"input_ids": torch.tensor([x0]), "src_mask": torch.tensor([src_mask])}
            score = eval_forward(model, inputs, args, tokenizer)
            # import pdb; pdb.set_trace();
            score_list.append(score.tolist())
        pred = np.argmin(np.array(score_list))
        if pred == gold:
            cor += 1
        # print(total_cnt, cor/total_cnt)
    print('siqa acc:', cor/total_cnt)
    log_benchmark_result("siqa", {"acc": cor/total_cnt})



def eval_infilling(model, tokenizer, args):
    import csv
    import json

    print("ROCinfilling progress:")
    problems = []
    with open("/mnt/24-scale/LLaMA_Factory/evaluation/cloze_test_val__spring2016.csv") as f:
        reader = csv.reader(f)
        next(reader)
        for row in reader:
            sents = row[1:-3] + [row[-3] if row[-1] == "1" else row[-2]]
            problems.append(sents)

    samples = []
    total_cnt = 0
    gens = []
    refs = []

    for stories in problems:
        total_cnt += 1

        prompt = stories[0] + " " + stories[1]
        suffix = stories[3] + " " + stories[4]
        middle = stories[2]

        prefix = tokenizer.encode(prompt, add_special_tokens=False)
        suff = tokenizer.encode(suffix, add_special_tokens=False)
        middle_ids = tokenizer.encode(middle, add_special_tokens=False)

        x0 = prefix + middle_ids + suff
        src_mask = [1] * len(prefix) + [0] * len(middle_ids) + [1] * len(suff)

        inputs = {
            "input_ids": torch.tensor([x0]),
            "src_mask": torch.tensor([src_mask]),
        }

        res = generate_samples(model, args, tokenizer, inputs, eval=True)

        pred = tokenizer.decode(
            res.tolist()[0][len(prefix) - 1 : len(x0) - len(suff) - 1]
        )

        samples.append(
            {
                "pred": pred,
                "label": middle,
                "prefix": prompt,
                "suffix": suffix,
            }
        )
        gens.append(pred)
        refs.append(middle)

        if total_cnt == 1000:
            break

    from rouge_score import rouge_scorer, scoring

    scorer = rouge_scorer.RougeScorer(["rouge1", "rouge2", "rougeL"], use_stemmer=True)
    aggregator = scoring.BootstrapAggregator()

    for pred, ref in zip(gens, refs):
        scores = scorer.score(ref, pred)
        aggregator.add_scores(scores)

    agg = aggregator.aggregate()
    results = {
        "rouge1": agg["rouge1"].mid.fmeasure * 100,
        "rouge2": agg["rouge2"].mid.fmeasure * 100,
        "rougeL": agg["rougeL"].mid.fmeasure * 100,
    }
    results["rougeAvg"] = (results["rouge1"] + results["rouge2"] + results["rougeL"]) / 3

    print(
        f"rouge1={results['rouge1']:.2f}, "
        f"rouge2={results['rouge2']:.2f}, "
        f"rougeL={results['rougeL']:.2f}, "
        f"rougeAvg={results['rougeAvg']:.2f}"
    )

    with open(
        f"ROCInfill_medium_t{args.diffusion_steps}_tmp{args.logits_temp}.jsonl",
        "w",
    ) as f:
        for json_obj in samples:
            f.write(json.dumps(json_obj) + "\n")

    # log_benchmark_result("roc_infilling", results)
    log_benchmark_result("ROCinfilling progress", {"rouge1": results["rouge1"], "rouge2": results["rouge2"], "rougeL": results["rougeL"], "rougeAvg": results["rougeAvg"]})

# data_path = "/mnt/dataset/test_data/human_eval_infilling/single-line.jsonl"
    # data_path = "/mnt/dataset/test_dataset/human_eval_infilling/data/HumanEval-SingleLineInfilling.jsonl.gz"
import gzip


def humaneval_infill(model, tokenizer, args):
    import os
    import ast
    import subprocess
    import sys
    import gzip
    import json
    print("humaneval_infill-code process")
    subtasks = "single-line"
    env = os.environ.copy()
    env["PYTHONPATH"] = "/mnt/dataset/test_dataset/human_eval_infilling:" + env.get("PYTHONPATH", "")
    eval_script = "/mnt/dataset/test_dataset/human_eval_infilling/human_eval_infilling/evaluate_functional_correctness.py"
    data_path = "/mnt/dataset/test_dataset/human_eval_infilling/data/HumanEval-SingleLineInfilling.jsonl.gz"
    problems = {}
    with gzip.open(data_path, "rt", encoding="utf-8") as f:
        for line in f:
            obj = json.loads(line)
            problems[obj["task_id"]] = obj
    samples = []
    for task_id in problems:
        # import pdb; pdb.set_trace();
        prompt = problems[task_id]["prompt"]
        suffix = problems[task_id]["suffix"]
        middle = problems[task_id]["canonical_solution"]

        prefix = tokenizer.encode(prompt, add_special_tokens=False)
        suff = tokenizer.encode(suffix, add_special_tokens=False)
        x0 = prefix + tokenizer.encode(middle, add_special_tokens=False) + suff
        src_mask = [1] * len(prefix) + [0] * (len(x0) - len(prefix) - len(suff)) + [1] * len(suff)
        if len(x0) > 1000:
            print(task_id)
            samples.append(dict(task_id=task_id, completion=""))
            continue
        inputs = {"input_ids": torch.tensor([x0]), "src_mask": torch.tensor([src_mask])}
        res = generate_samples(model, args, tokenizer, inputs, eval=True)
        pred = tokenizer.decode(res.tolist()[0][len(prefix) - 1:len(x0) - len(suff) - 1])
        samples.append(dict(task_id=task_id, completion=pred))

    out_path = f"humaneval_medium_samplingv1_{subtasks}.jsonl"
    # write_jsonl(out_path, samples)
    with open(out_path, "w", encoding="utf-8") as f:
        for s in samples:
            f.write(json.dumps(s, ensure_ascii=False) + "\n")

    result = subprocess.run(
        [
            sys.executable,
            eval_script,
            "--sample_file",
            out_path,
            "--benchmark_name",
            subtasks,
        ],
        capture_output = True,
        text = True,
        env = env,
    )
    print(result.stdout)
    if result.stderr:
        print(result.stderr)
    pass_at_1 = None
    for line in result.stdout.splitlines():
        if "pass@1" in line:
            try:
                metrics = ast.literal_eval(line.strip())
                pass_at_1 = metrics.get("pass@1", None)
            except Exception:
                pass
    if pass_at_1 is not None:
        log_benchmark_result(
            "humaneval_infill",
            {"pass@1": pass_at_1, "output_file": out_path}
        )


# import evaluate
def eval_infilling(model, tokenizer, args):
    import csv
    from rouge_score import rouge_scorer, scoring
    print("roc process:")
    problems = []
    with open(f"/mnt/24-scale/LLaMA_Factory/evaluation/evaluation/cloze_test_val__spring2016.csv") as f:
    # with open("/mnt/5-diffugpt-s/evaluation/cloze_test_val__spring2016.csv") as f:
        reader = csv.reader(f)
        next(reader)
        for row in reader:
            sents = row[1:-3] + [row[-3] if row[-1] == "1" else row[-2]]
            # sents = [s if i == 0 else " " + s for i, s in enumerate(sents)]
            problems.append(sents)

    samples = []
    total_cnt = 0
    gens = []
    refs = []

    for stories in problems:
        total_cnt += 1
        # import pdb; pdb.set_trace();
        prompt = stories[0] + " " + stories[1]
        suffix = stories[3] + " " + stories[4]
        middle = stories[2]

        prefix = tokenizer.encode(prompt, add_special_tokens=False)
        suff = tokenizer.encode(suffix, add_special_tokens=False)
        x0 = prefix + tokenizer.encode(middle, add_special_tokens=False) + suff
        src_mask = [1] * len(prefix) + [0] * (len(x0) - len(prefix) - len(suff)) + [1] * len(suff)
        inputs = {"input_ids": torch.tensor([x0]), "src_mask": torch.tensor([src_mask])}
        res = generate_samples(model, args, tokenizer, inputs, eval=True)
        pred = tokenizer.decode(res.tolist()[0][len(prefix) - 1:len(x0) - len(suff) - 1])

        samples.append(dict(pred=pred, label=middle, prefix=prompt, suffix=suffix))
        gens.append(pred)
        refs.append(middle)

        if total_cnt == 1000:
            break

    scorer = rouge_scorer.RougeScorer(["rouge1", "rouge2", "rougeL"], use_stemmer=True)
    aggregator = scoring.BootstrapAggregator()

    for pred, ref in zip(gens, refs):
        scores = scorer.score(ref, pred)
        aggregator.add_scores(scores)

    agg = aggregator.aggregate()
    results = {
        "rouge1": agg["rouge1"].mid.fmeasure * 100,
        "rouge2": agg["rouge2"].mid.fmeasure * 100,
        "rougeL": agg["rougeL"].mid.fmeasure * 100,
    }
    results["rougeAvg"] = (results["rouge1"] + results["rouge2"] + results["rougeL"]) / 3

    print(
        f"rouge1={results['rouge1']:.2f}, rouge2={results['rouge2']:.2f}, rougeL={results['rougeL']:.2f}, rougeAvg={results['rougeAvg']:.2f}")

    with open(f'ROCInfill_medium_t{args.diffusion_steps}_tmp{args.logits_temp}.jsonl', 'w') as f:
        for json_obj in samples:
            f.write(json.dumps(json_obj) + '\n')
    log_benchmark_result("roc_infilling", results)


def eval_squad(model, tokenizer, args):
    from datasets import load_dataset
    print("squad progress:")
    ds = load_dataset(
        "parquet",
        data_files="/mnt/dataset/test_dataset/squad/plain_text/validation-00000-of-00001.parquet",
        split="train",
    )
    gens = []
    refs = []
    total_cnt = 0
    cor = 0
    for doc in ds:
        total_cnt += 1

        query = f"{doc['context']}\nQuesion{doc['question']}?\nAnswer: "
        labels = doc["answers"]["text"]

        encoded_labels = [tokenizer.encode(l, add_special_tokens=False) for l in labels]
        long_gold = max(encoded_labels, key=len)
        input_ids = tokenizer.encode(query)
        full = long_gold
        tokens = len(full)
        x0 = input_ids + [0] * tokens
        src_mask = [1] * len(input_ids) + [0] * tokens
        args.diffusion_steps = tokens
        inputs = {
            "input_ids": torch.tensor([x0]),
            "src_mask": torch.tensor([src_mask]),
        }
        res = generate_samples(model, args, tokenizer, inputs, eval=True)
        pred = tokenizer.decode(res.tolist()[0][len(input_ids) - 1:])
        for l in labels:
            if normalize_answer(l) in normalize_answer(pred.strip()):
                cor += 1
                break
        gens.append(pred)
        refs.append(labels)
        if total_cnt == 2000:
            break
        # print(pred, labels)
    em_acc = cor / total_cnt
    f1 = compute_f1(gens, refs)
    print("squad em acc:", em_acc)
    print("squad f1:", f1)
    log_benchmark_result("squad", {"acc": em_acc, "f1": f1})


def eval_triviaqa(model, tokenizer, args):
    from datasets import load_dataset
    import torch

    print("triviaqa progress:")
    ds = load_dataset(
        "parquet",
        data_files="/mnt/dataset/test_dataset/trivia_qa/*.parquet",
        split="train",
    )

    gens = []
    refs = []
    total_cnt = 0
    cor = 0
    skipped = 0
    max_len = 1024

    for doc in ds:
        context = ""
        if "context" in doc and doc["context"]:
            context = doc["context"]
        elif "search_results" in doc and doc["search_results"]:
            sr = doc["search_results"]
            if isinstance(sr, dict):
                descs = sr.get("search_context", []) or sr.get("description", []) or []
                if isinstance(descs, list):
                    context = "\n".join([x for x in descs if isinstance(x, str) and x.strip()])
            elif isinstance(sr, list):
                context = "\n".join([str(x) for x in sr if str(x).strip()])
        elif "entity_pages" in doc and doc["entity_pages"]:
            ep = doc["entity_pages"]
            if isinstance(ep, dict):
                wiki_context = ep.get("wiki_context", []) or ep.get("description", []) or []
                if isinstance(wiki_context, list):
                    context = "\n".join([x for x in wiki_context if isinstance(x, str) and x.strip()])

        labels = doc["answer"]["aliases"]
        normal_labels = [normalize_answer(x) for x in doc["answer"]["normalized_aliases"]]

        encoded_labels = [tokenizer.encode(l, add_special_tokens=False) for l in labels]
        long_gold = max(encoded_labels, key=len)
        tokens = len(long_gold)

        question_part = f"\nQuestion: {doc['question']}\nAnswer: "
        question_ids = tokenizer.encode(question_part, add_special_tokens=False)

        if context and len(context) > 4000:
            context = context[-4000:]

        context_ids = tokenizer.encode(context, add_special_tokens=False) if context else []

        keep_ctx_len = max_len - len(question_ids) - tokens
        if keep_ctx_len < 0:
            keep_ctx_len = 0

        context_ids = context_ids[-keep_ctx_len:]
        input_ids = context_ids + question_ids

        if len(input_ids) + tokens > max_len:
            skipped += 1
            continue

        x0 = input_ids + [0] * tokens
        src_mask = [1] * len(input_ids) + [0] * tokens
        inputs = {
            "input_ids": torch.tensor([x0]),
            "src_mask": torch.tensor([src_mask]),
        }

        old_steps = args.diffusion_steps
        try:
            args.diffusion_steps = tokens
            res = generate_samples(model, args, tokenizer, inputs, eval=True)
        finally:
            args.diffusion_steps = old_steps

        pred = tokenizer.decode(res.tolist()[0][len(input_ids) - 1:]).strip()
        norm_pred = normalize_answer(pred)

        total_cnt += 1
        if norm_pred in normal_labels:
            cor += 1
        else:
            for l in normal_labels:
                if l in norm_pred:
                    cor += 1
                    break

        gens.append(pred)
        refs.append(labels)

        if total_cnt >= 2000:
            break

    em_acc = cor / total_cnt if total_cnt else 0.0
    f1 = compute_f1(gens, refs) if gens else 0.0

    print("TriviaQA em acc:", em_acc)
    print("TriviaQA f1:", f1)
    print("TriviaQA skipped:", skipped)

    log_benchmark_result("triviaqa", {"acc": em_acc, "f1": f1, "skipped": skipped})


def _extract_gsm8k_number(text: str) -> str:
    """从文本中提取最终数值答案（优先匹配 '#### 42'，否则取最后一个数字）。"""
    import re
    if text is None:
        return ""
    s = str(text).strip().replace(",", "")
    m = re.search(r"####\s*([\-]?\d+(?:\.\d+)?)", s)
    if m:
        return m.group(1)
    all_nums = re.findall(r"[\-]?\d+(?:\.\d+)?", s)
    return all_nums[-1] if all_nums else ""


import math
from transformers import AutoModelForCausalLM, AutoTokenizer

def distinct_2(texts):
    total = 0
    uniq = set()
    for text in texts:
        toks = text.strip().split()
        for i in range(len(toks) - 1):
            bg = (toks[i], toks[i + 1])
            uniq.add(bg)
            total += 1
    return len(uniq) / total if total > 0 else 0.0


@torch.no_grad()
def eval_unconditional_generation(model, tokenizer, args, gpt2_large_path, num_samples=64, gen_len=1024):
    # 1) 无条件生成
    print("eval_unconditional_generation progress:")
    gens = []
    for i in range(num_samples):
        gen_len = 1023
        # gen_len = 512
        x0 = [tokenizer.eos_token_id if tokenizer.eos_token_id is not None else 0] + [0] * gen_len
        src_mask = [1] + [0] * gen_len

        # x0 = [tokenizer.eos_token_id if tokenizer.eos_token_id is not None else 0] + [0] * gen_len
        # src_mask = [1] + [0] * gen_len
        args.diffusion_steps = gen_len

        inputs = {
            "input_ids": torch.tensor([x0]),
            "src_mask": torch.tensor([src_mask]),
        }

        res = generate_samples(model, args, tokenizer, inputs, eval=True)
        pred = tokenizer.decode(res.tolist()[0][1:], skip_special_tokens=True)
        gens.append(pred)
        # print(f"[uncond] {i+1}/{num_samples}")

    # 2) 用 GPT2-large 算 generative perplexity
    eval_tok = AutoTokenizer.from_pretrained(gpt2_large_path, local_files_only=True)
    eval_lm = AutoModelForCausalLM.from_pretrained(
        gpt2_large_path,
        device_map="auto",
        torch_dtype=torch.bfloat16,
        local_files_only=True,
    )
    eval_lm.eval()

    nll_sum = 0.0
    tok_sum = 0

    for text in gens:
        ids = eval_tok(text, return_tensors="pt", truncation=True, max_length=1024).input_ids.to(eval_lm.device)
        if ids.shape[1] < 2:
            continue
        out = eval_lm(ids, labels=ids)
        n_tokens = ids.shape[1] - 1
        nll_sum += out.loss.item() * n_tokens
        tok_sum += n_tokens

    gen_ppl = math.exp(nll_sum / tok_sum) if tok_sum > 0 else float("inf")
    dist2 = distinct_2(gens)

    print(f"unconditional_generative_ppl: {gen_ppl:.4f}")
    print(f"unconditional_distinct2: {dist2:.4f}")
    log_benchmark_result("eval_unconditional_generation progress", {"ppl": gen_ppl, "distinct2": dist2})



def _gsm8k_fewshot_prompt(n_shot: int = 8):
    """
    Chain-of-thought few-shot prompt for GSM8K.

    DiffuLLaMA 论文对 fine-tuned 模型的评测使用了标准 GSM8K CoT 格式；
    对于 zero-shot / few-shot 评测，使用与原论文（Wei et al., 2022）相同的 8 条示例。
    通过 --gsm8k_fewshot 0 可关闭（zero-shot）；传 4 使用前 4 条。
    """
    _ALL_SHOTS = [
        (
            "There are 15 trees in the grove. Grove workers will plant trees in the grove today. "
            "After they are done, there will be 21 trees. How many trees did the grove workers plant today?",
            "There are 21 trees after planting and 15 trees before, so the workers planted 21 - 15 = <<21-15=6>>6 trees. #### 6",
        ),
        (
            "If there are 3 cars in the parking lot and 2 more cars arrive, how many cars are in the parking lot?",
            "There are 3 cars in the parking lot already. 2 more arrive. Now there are 3 + 2 = <<3+2=5>>5 cars. #### 5",
        ),
        (
            "Leah had 32 chocolates and her sister had 42. If they ate 35, how many pieces do they have left in total?",
            "Leah had 32 chocolates and her sister had 42, so together they had 32 + 42 = <<32+42=74>>74. "
            "After eating 35, they had 74 - 35 = <<74-35=39>>39 chocolates. #### 39",
        ),
        (
            "Jason had 20 lollipops. He gave Denny some lollipops. Now Jason has 12 lollipops. "
            "How many lollipops did Jason give to Denny?",
            "Jason started with 20 lollipops. Then he gave some to Denny and was left with 12. "
            "So he gave Denny 20 - 12 = <<20-12=8>>8 lollipops. #### 8",
        ),
        (
            "Shawn has five toys. For Christmas, he got two toys each from his mom and dad. "
            "How many toys does he have now?",
            "He has 5 toys. He got 2 from mom, so after that he has 5 + 2 = <<5+2=7>>7. "
            "Then he got 2 more from dad, so he has 7 + 2 = <<7+2=9>>9. #### 9",
        ),
        (
            "There were nine computers in the server room. Five more computers were installed each day, "
            "from Monday to Thursday. How many computers are now in the server room?",
            "From Monday to Thursday there are 4 days. 5 computers were added each day, "
            "so 4 * 5 = <<4*5=20>>20 computers were added. "
            "There are now 9 + 20 = <<9+20=29>>29 computers. #### 29",
        ),
        (
            "Michael had 58 golf balls. On Tuesday, he lost 23 golf balls. On Wednesday, he lost 2 more. "
            "How many golf balls did he have at the end of Wednesday?",
            "Michael started with 58 golf balls. He lost 23 on Tuesday, leaving him with "
            "58 - 23 = <<58-23=35>>35. On Wednesday he lost 2 more, so he has "
            "35 - 2 = <<35-2=33>>33. #### 33",
        ),
        (
            "Olivia has $23. She bought five bagels for $3 each. How much money does she have left?",
            "She bought 5 bagels for $3 each, spending 5 * 3 = <<5*3=15>>15 dollars. "
            "She has 23 - 15 = <<23-15=8>>8 dollars left. #### 8",
        ),
    ]
    k = min(n_shot, len(_ALL_SHOTS))
    lines = []
    for q, a in _ALL_SHOTS[:k]:
        lines.append(f"Question: {q}\nAnswer: {a}\n")
    return "\n".join(lines) + "\n"


# ── GSM8K 辅助函数 ─────────────────────────────────────────────────────────────

def _ensure_jsonl_from_parquet(path: str) -> str:
    """
    若 path 是 .parquet 文件，将其转换为临时 .jsonl 并返回新路径；
    否则直接返回原路径（支持 .jsonl / .json 直接读取）。
    """
    import os, json, tempfile
    if not path.endswith(".parquet"):
        return path
    try:
        import pandas as pd
        df = pd.read_parquet(path)
    except Exception:
        from datasets import load_dataset
        ds = load_dataset("parquet", data_files={"test": path}, split="test")
        tmp = tempfile.NamedTemporaryFile(
            mode="w", suffix=".jsonl", delete=False, encoding="utf-8"
        )
        for row in ds:
            tmp.write(json.dumps(row, ensure_ascii=False) + "\n")
        tmp.close()
        return tmp.name
    tmp = tempfile.NamedTemporaryFile(
        mode="w", suffix=".jsonl", delete=False, encoding="utf-8"
    )
    for _, row in df.iterrows():
        tmp.write(json.dumps(row.to_dict(), ensure_ascii=False) + "\n")
    tmp.close()
    return tmp.name


def _gsm8k_gold_answer(answer_str: str) -> str:
    """从 GSM8K 原始 answer 字段中提取 '#### 数字' 后面的数值字符串。"""
    import re
    if answer_str is None:
        return ""
    m = re.search(r"####\s*([\-]?\d[\d,]*(?:\.\d+)?)", str(answer_str))
    if m:
        return m.group(1).replace(",", "")
    return ""


def _gsm8k_normalize_answer(raw: str) -> str | None:
    """规范化数值字符串：去掉逗号、尾随零；空字符串返回 None。"""
    if not raw:
        return None
    raw = raw.replace(",", "").strip()
    try:
        val = float(raw)
        if val == int(val):
            return str(int(val))
        return f"{val:.6f}".rstrip("0").rstrip(".")
    except ValueError:
        return raw if raw else None


def _gsm8k_extract_number(text: str) -> str:
    """
    从模型输出中提取最终答案数字：
      1. 优先匹配 '#### 42' 格式（GSM8K 标准格式）；
      2. 否则取文本中最后一个数字。
    """
    import re
    if text is None:
        return ""
    s = str(text).replace(",", "").strip()
    m = re.search(r"####\s*([\-]?\d+(?:\.\d+)?)", s)
    if m:
        return m.group(1)
    nums = re.findall(r"[\-]?\d+(?:\.\d+)?", s)
    return nums[-1] if nums else ""


def eval_gsm8k(model, tokenizer, args):
    """
    GSM8K evaluation for DiffuGPT/DiffuLLaMA-style infilling generation.

    关于 DiffuLLaMA 论文的 GSM8K 测试方式：
      - 论文 Table 1 中的 GSM8K 结果来自微调后的模型（DiffuLLaMA-GSM，基于 LoRA 在
        GSM8K-symbolic 数据集上微调），并非 zero-shot。
      - 若要仿真其 fine-tuned 评测，需先对模型做 LoRA 微调，再用本函数评测。
      - 若只评测 pre-trained 模型，可使用 --gsm8k_fewshot 8 进行 8-shot CoT 评测，
        与 DiffuLLaMA 论文的 few-shot 基准对齐。

    Required args:
      --gsm8k_path             GSM8K parquet/jsonl 测试集路径
      --gsm8k_max_samples      最多评测样本数（默认 1319，即全集）
      --gsm8k_answer_tokens    扩散生成的 answer slot 长度（默认 256，CoT 够用）
      --gsm8k_fewshot          few-shot 示例数（0=zero-shot, 4 或 8 推荐）
      --gsm8k_diffusion_steps  GSM8K 专用扩散步数，不传则使用 answer_tokens
    """
    import json
    import os
    import torch

    print("gsm8k progress:")

    path = getattr(
        args,
        "gsm8k_path",
        "/mnt/dataset/gsm8k/test-00000-of-00001.parquet",
    )
    path = _ensure_jsonl_from_parquet(path)

    max_samples = int(getattr(args, "gsm8k_max_samples", 1319))
    answer_tokens = int(getattr(args, "gsm8k_answer_tokens", 256))
    fewshot = int(getattr(args, "gsm8k_fewshot", 0))
    # 允许独立控制 GSM8K 的扩散步数，不传则与 answer_tokens 对齐
    gsm8k_steps = int(getattr(args, "gsm8k_diffusion_steps", None) or answer_tokens)

    if not os.path.exists(path):
        raise FileNotFoundError(f"GSM8K file not found: {path}")

    # Save generation args.
    old_steps = getattr(args, "diffusion_steps", None)
    old_temp = getattr(args, "logits_temp", None)

    if old_steps is not None:
        args.diffusion_steps = gsm8k_steps
    if old_temp is not None:
        args.logits_temp = 1.0

    prefix_demo = _gsm8k_fewshot_prompt(fewshot) if fewshot > 0 else ""

    total = 0
    correct = 0
    skipped = 0
    parse_fail = 0

    examples_to_print = 3

    model.eval()

    with open(path, "r", encoding="utf-8") as f:
        for line_idx, line in enumerate(f):
            if total >= max_samples:
                break

            if not line.strip():
                continue

            ex = json.loads(line)
            question = ex.get("question", None)
            answer = ex.get("answer", None)

            if question is None or answer is None:
                skipped += 1
                continue

            gold_raw = _gsm8k_gold_answer(answer)
            gold = _gsm8k_normalize_answer(gold_raw)

            if gold is None:
                skipped += 1
                continue

            prompt = (
                prefix_demo
                + "Question: "
                + question.strip()
                + "\nAnswer: Let's think step by step. "
            )

            prefix_ids = tokenizer.encode(prompt, add_special_tokens=False)

            # Diffusion infilling format:
            # known prompt tokens + unknown answer slots.
            input_ids = prefix_ids + [0] * answer_tokens
            src_mask = [1] * len(prefix_ids) + [0] * answer_tokens

            inputs = {
                "input_ids": torch.tensor([input_ids], dtype=torch.long).to(model.device),
                "src_mask": torch.tensor([src_mask], dtype=torch.long).to(model.device),
            }

            with torch.no_grad():
                res = generate_samples(model, args, tokenizer, inputs, eval=True)

            # res shape is assumed [1, seq_len].
            out_ids = res.tolist()[0]
            gen_ids = out_ids[len(prefix_ids):]
            pred_text = tokenizer.decode(gen_ids, skip_special_tokens=True)

            pred_raw = _gsm8k_extract_number(pred_text)
            pred = _gsm8k_normalize_answer(pred_raw)

            total += 1

            if pred is None:
                parse_fail += 1
            elif pred == gold:
                correct += 1

            if total <= examples_to_print:
                print("=" * 80)
                print(f"[GSM8K example {total}]")
                print("Q:", question)
                print("Gold:", gold)
                print("Pred:", pred)
                print("Generated:", pred_text[:500])

            if total % 50 == 0:
                print(
                    f"[GSM8K] {total}/{max_samples} "
                    f"acc={correct / max(total, 1):.4f} "
                    f"parse_fail={parse_fail}"
                )

    # Restore args.
    if old_steps is not None:
        args.diffusion_steps = old_steps
    if old_temp is not None:
        args.logits_temp = old_temp

    acc = correct / max(total, 1)

    result = {
        "acc": acc,
        "total": total,
        "correct": correct,
        "skipped": skipped,
        "parse_fail": parse_fail,
    }

    print(
        f"GSM8K acc: {acc:.4f}, "
        f"correct={correct}, total={total}, skipped={skipped}, parse_fail={parse_fail}"
    )

    # If your script already defines log_benchmark_result, use it.
    if "log_benchmark_result" in globals():
        log_benchmark_result("gsm8k", result)

    return result




def main():
    parser = ArgumentParser()
    parser.add_argument("--model_name", type=str, default='diffusionfamily/diffugpt-s')
    parser.add_argument("--base_model_name", type=str, default='gpt2')
    parser.add_argument("--shift", type=bool, default=True) # do not change this
    parser.add_argument("--diffusion_steps", type=int, default=32)
    parser.add_argument("--logits_temp", type=float, default=0.95)
    parser.add_argument("--topp_temp", type=float, default=0.9)
    parser.add_argument("--verbose", type=bool, default=False) # print middle state
    parser.add_argument("--gpt2_large_path", type=str, default="/mnt/dataset/ckpt/gpt2-large")
    parser.add_argument("--compare_checkpoints", action="store_true")
    parser.add_argument("--base_model_path", type=str, default="/mnt/dataset/ckpt/diffugpt-s")
    parser.add_argument("--ours_state_dict", type=str, default=None,
                        help="ours 单 checkpoint 路径（.pt 或 HF 目录）。与 --node_state_dicts 二选一。")
    parser.add_argument("--full_state_dict", type=str, default=None,
                        help="full-merge checkpoint 路径（.pt 或 HF 目录）。")
    # ── 多节点离线 router 支持 ────────────────────────────────────────
    parser.add_argument(
        "--node_state_dicts",
        type=str,
        default=None,
        help="逗号分隔的多个节点 checkpoint 路径（如 node0.pt,node1.pt,…）。"
             "脚本会对这些节点权重做简单平均作为 ours 共享底座，"
             "然后再附加 --ours_dynfuse_bundle 中的 router。",
    )
    parser.add_argument(
        "--ours_dynfuse_bundle",
        type=str,
        default=None,
        help="DynFuse 离线 router 包路径（dynfuse_offline.pt），由训练时 export 生成。"
             "若提供，会自动附加到 ours 模型上进行时间步感知动态路由。",
    )
    parser.add_argument(
        "--full_node_state_dicts",
        type=str,
        default=None,
        help="逗号分隔的多节点 checkpoint 路径，用于构造 full-merge baseline（与 --node_state_dicts 同一批节点权重）。"
             "使两侧使用完全相同的原始节点权重，仅在是否附加 DynFuse router 上做对比，保证评测公平性。"
             "若未提供，full 侧退回到 --full_state_dict 单 checkpoint。",
    )
    # ── 下游任务成对评测（论文副表） ─────────────────────────────────
    parser.add_argument(
        "--run_benchmarks",
        action="store_true",
        help="在 compare_checkpoints 模式下，额外对 ours/full 两个模型都跑全部下游基准任务"
             "（Lambada / HellaSwag / HumanEval / ROCStories / PIQA / SIQA / WINO / SQuAD / TriviaQA / GenPPL）。"
             "结果写入 JSON 并上传 wandb Table。",
    )
    parser.add_argument("--gsm8k_path", type=str, default=None,
                        help="GSM8K parquet/jsonl 测试集路径（提供后自动加入 eval_all_tasks，或配合 --gsm8k_only 单独使用）")
    parser.add_argument("--gsm8k_max_samples", type=int, default=1319,
                        help="GSM8K 最多评测样本数，默认 1319（全集）")
    parser.add_argument("--gsm8k_answer_tokens", type=int, default=256,
                        help="扩散生成的 answer slot token 数，CoT 推荐 ≥256")
    parser.add_argument("--gsm8k_fewshot", type=int, default=0,
                        help="Few-shot 示例数：0=zero-shot，4 或 8 与 DiffuLLaMA 论文对齐")
    parser.add_argument("--gsm8k_diffusion_steps", type=int, default=None,
                        help="GSM8K 专用扩散步数，默认与 gsm8k_answer_tokens 相同；"
                             "DiffuLLaMA 原始代码用 256 步对应 256 个 answer token")
    parser.add_argument(
        "--gsm8k_only",
        action="store_true",
        help=(
            "仅运行 GSM8K 评测，跳过其它所有基准。\n"
            "  * 搭配 --base_model_path + --ours_state_dict 加载本地 checkpoint；\n"
            "  * 搭配 --gsm8k_fewshot 8 可对齐 DiffuLLaMA 论文的 8-shot CoT 结果；\n"
            "  * DiffuLLaMA 论文 Table-1 的 GSM8K 分数来自 LoRA 微调模型，\n"
            "    若评测 pre-trained 权重请使用 few-shot 模式以获得合理分数。"
        ),
    )
    parser.add_argument(
        "--measure_latency",
        action="store_true",
        help="测量统一基准下的推理时延与吞吐，用于论文中的 Inference Overhead / Latency。",
    )
    parser.add_argument("--latency_warmup_runs", type=int, default=3)
    parser.add_argument("--latency_bench_runs", type=int, default=10)
    parser.add_argument("--latency_batch_size", type=int, default=1)
    parser.add_argument("--latency_seq_len", type=int, default=128)
    # ────────────────────────────────────────────────────────────────
    parser.add_argument("--mixed_val_paths", type=str, default=None)
    parser.add_argument("--mixed_val_weights", type=str, default=None)
    parser.add_argument("--domain_names", type=str, default=None)
    parser.add_argument("--domain_paths", type=str, default=None)
    parser.add_argument("--val_max_batches", type=int, default=50)
    parser.add_argument("--batch_size", type=int, default=4)
    parser.add_argument("--sampling_eps", type=float, default=1e-3)
    parser.add_argument("--anneal_steps", type=int, default=1)
    parser.add_argument("--output_json", type=str, default=None)
    parser.add_argument("--eval_step", type=int, default=None,
                        help="用作 wandb 折线图横轴（建议填 checkpoint 的 step 数，如 200）")
    parser.add_argument("--log_wandb", action="store_true")
    parser.add_argument("--wandb_project", type=str, default="hivemind_debug")
    parser.add_argument("--wandb_entity", type=str, default=None)
    parser.add_argument("--wandb_run_name", type=str, default=None)
    parser.add_argument(
        "--wandb-run-id",
        dest="wandb_run_id",
        type=str,
        default=None,
        help="固定 run id；多次 compare 时传相同 id + resume，可把 step=200/400 画在同一 run 的折线图上",
    )
    parser.add_argument("--wandb_mode", type=str, default="online", choices=["online", "offline", "disabled"])
    parser.add_argument(
        "--wandb-minimal",
        dest="wandb_minimal",
        action="store_true",
        help="仅上传标量指标（折线图够用），跳过 Table/柱状图 artifact，上传更快、终端刷屏更少",
    )

    args = parser.parse_args()

    # ── GSM8K 独立评测模式 ─────────────────────────────────────────────────────
    # 仅加载一个 checkpoint，只跑 GSM8K，不跑其它基准。
    # 用法示例（对齐 DiffuLLaMA fine-tuned 风格，8-shot CoT）：
    #   python offline_eval_with_robust_metrics.py \
    #     --gsm8k_only \
    #     --base_model_path /mnt/dataset/ckpt/llama2-7b \
    #     --ours_state_dict /mnt/24-scale-exp/<run_dir> \
    #     --gsm8k_path /mnt/dataset/gsm8k/test-00000-of-00001.parquet \
    #     --gsm8k_fewshot 8 \
    #     --gsm8k_answer_tokens 256 \
    #     --gsm8k_diffusion_steps 256 \
    #     --diffusion_steps 256 \
    #     --gsm8k_max_samples 1319
    if getattr(args, "gsm8k_only", False):
        if not args.gsm8k_path:
            raise ValueError("--gsm8k_only 模式必须提供 --gsm8k_path")
        print(f"[gsm8k_only] 加载模型: base={args.base_model_path}  ckpt={args.ours_state_dict}")
        model, tokenizer, dynfuse_state = _load_model_with_dynfuse(
            base_model_path=args.base_model_path,
            state_dict_path=args.ours_state_dict,
        )
        fewshot_n = int(getattr(args, "gsm8k_fewshot", 0))
        print(
            f"[gsm8k_only] fewshot={fewshot_n}  answer_tokens={getattr(args,'gsm8k_answer_tokens',256)}"
            f"  max_samples={getattr(args,'gsm8k_max_samples',1319)}"
        )
        with _inject_dynfuse(dynfuse_state):
            result = eval_gsm8k(model, tokenizer, args)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        if args.output_json:
            with open(args.output_json, "w", encoding="utf-8") as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
        return

    if args.compare_checkpoints:
        node_dicts = _parse_csv(getattr(args, "node_state_dicts", None))
        full_node_dicts = _parse_csv(getattr(args, "full_node_state_dicts", None))
        has_ours = args.ours_state_dict is not None or bool(node_dicts)
        has_full = args.full_state_dict is not None or bool(full_node_dicts)
        if not has_ours or not has_full:
            raise ValueError(
                "compare_checkpoints 模式下必须提供:\n"
                "  ours 侧: --ours_state_dict 或 --node_state_dicts\n"
                "  full 侧: --full_state_dict 或 --full_node_state_dicts\n"
                "  （推荐：ours 侧用 --node_state_dicts + --ours_dynfuse_bundle，"
                "full 侧用 --full_node_state_dicts 同一批节点权重，保证公平对比）"
            )
        compare_two_checkpoints(args)
        return

    # 单模型加载：优先使用 _load_model_with_dynfuse（支持原始 checkpoint 目录）
    # 用法 1（原始 checkpoint 目录）：
    #   --base_model_path /mnt/dataset/ckpt/llama2-7b
    #   --ours_state_dict /mnt/24-scale-exp/<run_dir>
    # 用法 2（HuggingFace hub / HF 格式目录）：
    #   --model_name diffusionfamily/diffugpt-s  （或本地 HF 格式目录，不传 --ours_state_dict）
    model_name = args.model_name
    if args.ours_state_dict is not None:
        print(f"[single] 使用 _load_model_with_dynfuse 加载原始 checkpoint")
        print(f"  base : {args.base_model_path}")
        print(f"  ckpt : {args.ours_state_dict}")
        model, tokenizer, dynfuse_state = _load_model_with_dynfuse(
            base_model_path=args.base_model_path,
            state_dict_path=args.ours_state_dict,
        )
    else:
        config = AutoConfig.from_pretrained(model_name)
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = DiscreteDiffusionModel.from_pretrained(
            model_name,
            model=args.base_model_name,
            config=config,
            tokenizer=tokenizer,
            device='cuda'
        ).to('cuda')
        dynfuse_state = None

    # 单模型评测也统一走 eval_all_tasks，保证和 compare_checkpoints 完全一致（GenPPL/Distinct-2 等对齐）
    single_result = {
        "model_name": model_name,
        "benchmarks": eval_all_tasks(model, tokenizer, args, dynfuse_state=dynfuse_state, label="single"),
        "extra_params": _compute_dynfuse_extra_params(dynfuse_state),
    }
    if args.measure_latency:
        single_result["latency"] = _measure_inference_latency(
            model, tokenizer, dynfuse_state=None,
            warmup_runs=args.latency_warmup_runs,
            bench_runs=args.latency_bench_runs,
            batch_size=args.latency_batch_size,
            seq_len=args.latency_seq_len,
            sampling_eps=args.sampling_eps,
            anneal_steps=args.anneal_steps,
            shift=args.shift,
        )
    print(json.dumps(single_result, ensure_ascii=False, indent=2))
    if args.output_json:
        with open(args.output_json, "w", encoding="utf-8") as f:
            json.dump(single_result, f, ensure_ascii=False, indent=2)


import pdb
if __name__ == "__main__":
    main()