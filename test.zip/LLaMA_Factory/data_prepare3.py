import os
import glob
from itertools import chain
from datasets import load_dataset
from transformers import AutoTokenizer

MODEL_PATH = "/mnt/dataset/ckpt/diffugpt-s"
INPUT_DIR = "/mnt/dataset/arxiv/train"
OUTPUT_DIR = "/mnt/dataset/arxiv/arxiv_tokenized_1024_packed"
SEQ_LEN = 1024
NUM_PROC = 16

def main():
    files = sorted(glob.glob(os.path.join(INPUT_DIR, "*.jsonl.zst")))
    if not files:
        raise FileNotFoundError(f"No jsonl.zst files found in {INPUT_DIR}")

    print(f"Found {len(files)} files")

    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, use_fast=True)

    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    ds = load_dataset(
        "json",
        data_files={"train": files},
        split="train",
    )

    print(ds)
    print("Columns:", ds.column_names)

    if "text" not in ds.column_names:
        raise ValueError(f"Need 'text' column, got: {ds.column_names}")

    def tokenize_function(batch):
        return tokenizer(batch["text"])

    tokenized = ds.map(
        tokenize_function,
        batched=True,
        num_proc=NUM_PROC,
        remove_columns=ds.column_names,
        desc="Tokenizing",
    )

    def group_texts(examples):
        concatenated = {
            k: list(chain.from_iterable(examples[k]))
            for k in examples.keys()
        }

        total_length = len(concatenated["input_ids"])
        total_length = (total_length // SEQ_LEN) * SEQ_LEN

        result = {
            k: [
                t[i : i + SEQ_LEN]
                for i in range(0, total_length, SEQ_LEN)
            ]
            for k, t in concatenated.items()
        }

        result["labels"] = result["input_ids"].copy()
        return result

    lm_ds = tokenized.map(
        group_texts,
        batched=True,
        num_proc=NUM_PROC,
        desc=f"Grouping texts into {SEQ_LEN}-token blocks",
    )

    lm_ds.save_to_disk(OUTPUT_DIR)
    print(f"Saved to: {OUTPUT_DIR}")

if __name__ == "__main__":
    main()